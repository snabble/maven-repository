package io.snabble.network.core

interface CredentialsCallback {

    fun onNewAppUser(appId: String, appSecret: String)
}
