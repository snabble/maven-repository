package io.snabble.network.core.credentials.di

import io.snabble.network.api.service.TokensService
import io.snabble.network.api.service.UsersService
import io.snabble.network.core.credentials.data.CredentialsRepositoryImpl
import io.snabble.network.core.credentials.domain.CredentialsRepository
import io.snabble.network.core.credentials.domain.usecase.CreateCredentialsUseCase
import io.snabble.network.core.credentials.domain.usecase.CreateCredentialsUseCaseImpl
import io.snabble.network.core.di.AUTH_FREE_RETROFIT
import org.koin.core.module.dsl.factoryOf
import org.koin.core.module.dsl.singleOf
import org.koin.core.qualifier.named
import org.koin.dsl.bind
import org.koin.dsl.module
import retrofit2.Retrofit

val credentialsModule = module {
    singleOf(::CredentialsRepositoryImpl) bind CredentialsRepository::class

    single {
        get<Retrofit>(named(AUTH_FREE_RETROFIT)).create(TokensService::class.java)
    } bind TokensService::class

    single {
        get<Retrofit>(named(AUTH_FREE_RETROFIT)).create(UsersService::class.java)
    } bind UsersService::class

    factoryOf(::CreateCredentialsUseCaseImpl) bind CreateCredentialsUseCase::class
}
