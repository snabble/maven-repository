package io.snabble.network.core.credentials.data

import io.snabble.network.api.dto.AppUserDto
import io.snabble.network.api.dto.CredentialsDto
import io.snabble.network.api.dto.TokenDto
import io.snabble.network.api.service.UsersService
import io.snabble.network.core.Config
import io.snabble.network.core.appuser.domain.AppUser
import io.snabble.network.core.authheader.data.serverTime
import io.snabble.network.core.authheader.domain.AuthHeaderValueRepository
import io.snabble.network.core.credentials.domain.Credentials
import io.snabble.network.core.credentials.domain.CredentialsRepository
import io.snabble.network.core.token.domain.Token

internal class CredentialsRepositoryImpl(
    private val usersService: UsersService,
    private val config: Config,
    private val authHeaderValueRepository: AuthHeaderValueRepository
) : CredentialsRepository {

    override suspend fun createCredentials(isRetry: Boolean): Credentials? {
        val appId: String = config.appId
        val projectId: String = config.projectId
        val secret: String = config.appSecret

        val authHeader: String =
            authHeaderValueRepository.getValueForUsersEndpoint(appId = appId, secret = secret) ?: return null

        val response = usersService.createCredentials(authHeader, appId, projectId)

        return if (!response.isSuccessful && !isRetry) {
            createCredentials(true)
        } else {
            authHeaderValueRepository.updateServerTimeOffset(response.headers().serverTime)
            response.body()?.toCredentials()
                ?.also { onNewAppUserCallback(it.appUser) }
        }
    }

    private fun onNewAppUserCallback(user: AppUser) {
        val id = user.id ?: return
        val secret = user.secret ?: return
        config.onNewAppCredentialsCallback?.onNewAppUser(
            appId = id,
            appSecret = secret
        )
    }
}

private fun CredentialsDto.toCredentials() = Credentials(
    token = this.tokenDto.toToken(),
    appUser = this.appUserDto.toAppUser()
)

private fun AppUserDto.toAppUser() = AppUser(
    id = id,
    secret = secret
)

internal fun TokenDto.toToken() = Token(
    id = id,
    value = value,
    issuedAt = issuedAt,
    expiresAt = expiresAt
)
