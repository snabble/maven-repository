package io.snabble.network.core.token.di

import io.snabble.network.core.token.data.TokenRepositoryImpl
import io.snabble.network.core.token.domain.TokenRepository
import io.snabble.network.core.token.domain.usecase.GetTokenUseCase
import io.snabble.network.core.token.domain.usecase.GetTokenUseCaseImpl
import io.snabble.network.core.token.domain.usecase.InvalidateTokenUseCase
import org.koin.core.module.dsl.factoryOf
import org.koin.dsl.bind
import org.koin.dsl.module

val tokenModule = module {
    factoryOf(::TokenRepositoryImpl) bind TokenRepository::class
    factoryOf(::GetTokenUseCaseImpl) bind GetTokenUseCase::class
    single { InvalidateTokenUseCase(get<TokenRepository>()::invalidateToken) } bind InvalidateTokenUseCase::class
}
