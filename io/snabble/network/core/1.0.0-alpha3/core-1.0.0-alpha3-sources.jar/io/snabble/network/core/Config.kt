package io.snabble.network.core

import io.snabble.network.api.converter.kotlinx.serialization.OnDeserializingFailed
import io.snabble.network.core.appuser.domain.AppUser
import kotlinx.coroutines.flow.Flow

interface Config {

    val projectId: String
    val appId: String
    val appSecret: String
    val appCredentials: AppUser?
    val baseUrl: String?
    val onNewAppCredentialsCallback: CredentialsCallback?
    val onDeserializingFailed: OnDeserializingFailed
    val appUserFlow: Flow<AppUser?>?
}
