package io.snabble.network.core.appuser.domain

interface AppUserRepository {

    fun saveAppUser(user: AppUser)

    fun getAppUser(): AppUser?
}
