package io.snabble.network.core.interceptor

import io.snabble.network.core.token.domain.usecase.GetTokenUseCase
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.Response

internal class PhoneAuthInterceptor(
    private val getAccessToken: GetTokenUseCase
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val token = runBlocking { getAccessToken() }
            ?: return chain.proceed(chain.request())

        return chain.proceed(chain.request().addAuthorizationHeader(token))
    }
}
