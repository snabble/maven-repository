package io.snabble.network.core.interceptor

import io.snabble.network.core.token.domain.Token
import okhttp3.Request

internal fun Request.addAuthorizationHeader(tokenDto: Token): Request = newBuilder()
    .header(AUTH_HEADER, "Bearer ${tokenDto.value}")
    .build()

internal const val AUTH_HEADER = "Authorization"
