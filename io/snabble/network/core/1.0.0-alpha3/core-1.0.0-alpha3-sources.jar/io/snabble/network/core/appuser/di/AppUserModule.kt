package io.snabble.network.core.appuser.di

import io.snabble.network.core.appuser.data.AppUserRepositoryImpl
import io.snabble.network.core.appuser.domain.AppUserRepository
import io.snabble.network.core.appuser.domain.usecase.GetAppUserUseCase
import io.snabble.network.core.appuser.domain.usecase.SaveAppUserUseCase
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.bind
import org.koin.dsl.module

val appUserModule = module {
    singleOf(::AppUserRepositoryImpl) bind AppUserRepository::class
    factory { GetAppUserUseCase(get<AppUserRepository>()::getAppUser) } bind GetAppUserUseCase::class
    factory { SaveAppUserUseCase(get<AppUserRepository>()::saveAppUser) } bind SaveAppUserUseCase::class
}
