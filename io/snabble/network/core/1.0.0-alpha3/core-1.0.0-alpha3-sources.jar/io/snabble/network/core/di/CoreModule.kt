package io.snabble.network.core.di

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import io.snabble.network.api.converter.kotlinx.serialization.asConverterFactory
import io.snabble.network.api.retrofit.ApiResultCallAdapterFactory
import io.snabble.network.core.Config
import io.snabble.network.core.interceptor.PhoneAuthInterceptor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.serialization.json.Json
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import org.koin.core.qualifier.named
import org.koin.dsl.bind
import org.koin.dsl.module
import retrofit2.Converter
import retrofit2.Retrofit

val coreModule = module {
    single(named(BASE_URL)) { get<Config>().baseUrl }

    single(named(AUTH_FREE_RETROFIT)) {
        Retrofit.Builder()
            .client(get(named(AUTH_FREE_OK_HTTP_CLIENT)))
            .addConverterFactory(get(named(RETROFIT_JSON_CONVERTER_FACTORY)))
            .baseUrl(get<String>(named(BASE_URL)))
            .build()
    } bind Retrofit::class

    single(named(AUTH_FREE_OK_HTTP_CLIENT)) {
        OkHttpClient.Builder().build()
    } bind OkHttpClient::class

    factory { PhoneAuthInterceptor(getAccessToken = get()) } bind Interceptor::class

    factory(named(RETROFIT_JSON_CONVERTER_FACTORY)) {
        val contentType = "application/json; charset=utf-8".toMediaType()
        val onDeserializingFailed = get<Config>().onDeserializingFailed
        val gson: Gson = get()
        get<Json>().asConverterFactory(contentType, onDeserializingFailed, gson)
    } bind Converter.Factory::class

    factory { ApiResultCallAdapterFactory.create(get<Json>()) } bind ApiResultCallAdapterFactory::class

    factory { Json { ignoreUnknownKeys = true; isLenient = true } } bind Json::class

    single { CoroutineScope(SupervisorJob() + Dispatchers.Default) } bind CoroutineScope::class

    factory { GsonBuilder().create() } bind Gson::class
}

internal const val AUTH_FREE_OK_HTTP_CLIENT = "Auth-Free-OkHttpClient"
internal const val AUTH_FREE_RETROFIT = "Auth-Free-Retrofit"
const val RETROFIT_JSON_CONVERTER_FACTORY = "Retrofit-Json-Converter-Factory"
const val BASE_URL = "Network-Base-Url"
