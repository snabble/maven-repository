package io.snabble.network.core.credentials.domain.usecase

import io.snabble.network.core.appuser.domain.usecase.SaveAppUserUseCase
import io.snabble.network.core.credentials.domain.Credentials
import io.snabble.network.core.credentials.domain.CredentialsRepository

internal interface CreateCredentialsUseCase {

    suspend operator fun invoke(): Credentials?
}

internal class CreateCredentialsUseCaseImpl(
    private val credentialsRepository: CredentialsRepository,
    private val saveAppUser: SaveAppUserUseCase
) : CreateCredentialsUseCase {

    override suspend fun invoke(): Credentials? = credentialsRepository.createCredentials(isRetry = false)
        ?.also { saveAppUser(it.appUser) }
}
