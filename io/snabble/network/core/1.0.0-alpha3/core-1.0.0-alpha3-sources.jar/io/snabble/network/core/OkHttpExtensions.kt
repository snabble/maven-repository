package io.snabble.network.core

import com.google.gson.Gson
import com.google.gson.JsonParseException
import io.snabble.network.api.converter.kotlinx.serialization.OnDeserializingFailed
import io.snabble.network.api.dto.error.StructuredErrorDto
import io.snabble.network.api.dto.error.ValidationsErrorDto
import io.snabble.network.api.retrofit.INVALID_REQUEST
import io.snabble.network.api.retrofit.toSnabbleError
import io.snabble.network.result.Result
import io.snabble.network.result.error.SnabbleError
import io.snabble.network.result.error.UnknownError
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.json.Json
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume

suspend inline fun <reified T> OkHttpClient.getResult(
    request: Request,
    gson: Gson,
    json: Json? = null,
    noinline onFailed: OnDeserializingFailed? = null
): Result<T> = suspendCancellableCoroutine { continuation ->
    val call = newCall(request)
    call.enqueue(object : Callback {

        override fun onFailure(call: Call, e: IOException) {
            continuation.resume(Result.failure(exception = e, error = UnknownError))
        }

        override fun onResponse(call: Call, response: Response) {
            when {
                response.isSuccessful -> continuation.resume(response.toResult(gson, json, onFailed))

                else -> {
                    continuation.resume(
                        Result.failure(
                            exception = OkHttpException(response.message),
                            error = response.toErrorResponse(gson, json, onFailed)
                        )
                    )
                }
            }
        }
    })

    continuation.invokeOnCancellation { call.cancel() }
}

inline fun <reified T> Response.toResult(
    gson: Gson,
    json: Json?,
    noinline onFailed: OnDeserializingFailed?
): Result<T> = when (val obj = toSuccessResponse<T>(gson, json, onFailed)) {
    null -> {
        Result.failure(
            exception = OkHttpException(message),
            error = UnknownError
        )
    }

    else -> Result.success(obj)
}

suspend inline fun <reified T> OkHttpClient.getNullableResult(
    request: Request,
    gson: Gson,
    json: Json?,
    noinline onFailed: OnDeserializingFailed?
): Result<T?> = suspendCancellableCoroutine { continuation ->
    val call = newCall(request)
    call.enqueue(object : Callback {

        override fun onFailure(call: Call, e: IOException) {
            continuation.resume(Result.failure(e, error = UnknownError))
        }

        override fun onResponse(call: Call, response: Response) {
            when {
                response.isSuccessful -> continuation.resume(
                    Result.success(response.toSuccessResponse(gson, json, onFailed))
                )

                else -> {
                    continuation.resume(
                        Result.failure(
                            exception = OkHttpException(response.message),
                            error = response.toErrorResponse(gson, json, onFailed)
                        )
                    )
                }
            }
        }
    })

    continuation.invokeOnCancellation { call.cancel() }
}

inline fun <reified T> Response.toSuccessResponse(
    gson: Gson,
    json: Json?,
    noinline onDeserializingFailed: OnDeserializingFailed?
): T? = body?.string()?.parse(gson, json, onDeserializingFailed)

fun Response.toErrorResponse(gson: Gson, json: Json?, onFailed: OnDeserializingFailed?): SnabbleError = when {
    code != INVALID_REQUEST -> body?.string()?.parse<StructuredErrorDto>(gson, json, onFailed)
    else -> body?.string()?.parse<ValidationsErrorDto>(gson, json, onFailed)
}.toSnabbleError()

inline fun <reified T> String.parse(
    gson: Gson,
    json: Json?,
    noinline onFailed: OnDeserializingFailed?
): T? = when (json) {
    null -> try {
        gson.fromJson(this, T::class.java)
    } catch (ignored: JsonParseException) {
        null
    }

    else -> try {
        json.decodeFromString(this)
    } catch (e: IllegalArgumentException) {
        onFailed?.invoke(e)
        try {
            gson.fromJson(this, T::class.java)
        } catch (ignored: JsonParseException) {
            null
        }
    }
}
