package io.snabble.network.core.token.domain.usecase

fun interface InvalidateTokenUseCase : () -> Unit
