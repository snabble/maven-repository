package io.snabble.network.core.appuser.data

import io.snabble.network.core.Config
import io.snabble.network.core.appuser.domain.AppUser
import io.snabble.network.core.appuser.domain.AppUserRepository
import io.snabble.network.core.token.domain.usecase.InvalidateTokenUseCase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

class AppUserRepositoryImpl(
    config: Config,
    invalidateTokenUseCase: InvalidateTokenUseCase,
    coroutineScope: CoroutineScope
) : AppUserRepository {

    init {
        config.appUserFlow
            ?.onEach { user ->
                if (cachedAppUser != user) {
                    cachedAppUser = user
                    invalidateTokenUseCase()
                }
            }
            ?.launchIn(coroutineScope)
    }

    private var cachedAppUser: AppUser? = config.appCredentials

    override fun getAppUser(): AppUser? = cachedAppUser

    override fun saveAppUser(user: AppUser) {
        cachedAppUser = user
    }
}
