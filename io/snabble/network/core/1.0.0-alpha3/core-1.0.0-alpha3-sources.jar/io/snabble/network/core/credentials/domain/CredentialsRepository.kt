package io.snabble.network.core.credentials.domain

internal interface CredentialsRepository {

    suspend fun createCredentials(isRetry: Boolean): Credentials?
}
