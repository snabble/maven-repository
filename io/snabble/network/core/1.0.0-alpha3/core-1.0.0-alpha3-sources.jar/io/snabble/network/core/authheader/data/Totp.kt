package io.snabble.network.core.authheader.data

import java.io.ByteArrayInputStream
import java.io.DataInput
import java.io.DataInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.security.GeneralSecurityException
import java.time.Instant
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Class to generate RFC 6238 time-based one time passwords.
 *
 *
 * Based on the Google Authenticator implementation.
 *
 *
 * See https://tools.ietf.org/html/rfc6238
 * See https://github.com/google/google-authenticator-android
 */
class Totp(
    algorithm: String?,
    secret: ByteArray?,
    private val length: Int,
    private val timeStep: Int
) {

    private lateinit var mac: Mac

    init {
        try {
            mac = Mac.getInstance(algorithm)
            mac.init(SecretKeySpec(secret, "RAW"))
        } catch (e: GeneralSecurityException) {
            println(e.localizedMessage)
        }
    }

    fun generate(instant: Instant): String {
        val counter = instant.epochSecond / timeStep
        val value = ByteBuffer.allocate(8).putLong(counter).array()
        val hash = mac.doFinal(value)

        // Dynamically truncate the hash
        // OffsetBits are the low order bits of the last byte of the hash
        val offset = hash[hash.size - 1].toInt() and 0xF

        // Grab a positive integer value starting at the given offset.
        val truncatedHash = hashToInt(hash, offset) and 0x7FFFFFFF
        val pinValue = truncatedHash % DIGITS_POWER[length]

        // Add padding
        var result = pinValue.toString()
        for (i in result.length until length) {
            result = "0$result"
        }
        return result
    }

    private fun hashToInt(bytes: ByteArray, start: Int): Int {
        val input: DataInput = DataInputStream(ByteArrayInputStream(bytes, start, bytes.size - start))
        val result: Int = try {
            input.readInt()
        } catch (e: IOException) {
            throw IllegalStateException(e)
        }
        return result
    }

    companion object {

        // 0 1 2 3 4 5 6 7 8 9
        private val DIGITS_POWER = intArrayOf(1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000)
    }
}
