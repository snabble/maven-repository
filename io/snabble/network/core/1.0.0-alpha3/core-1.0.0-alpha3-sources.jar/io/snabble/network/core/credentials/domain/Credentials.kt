package io.snabble.network.core.credentials.domain

import io.snabble.network.core.appuser.domain.AppUser
import io.snabble.network.core.token.domain.Token

data class Credentials(
    val token: Token,
    val appUser: AppUser
)
