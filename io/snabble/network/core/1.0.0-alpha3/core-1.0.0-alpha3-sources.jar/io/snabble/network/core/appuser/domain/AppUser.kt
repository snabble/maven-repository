package io.snabble.network.core.appuser.domain

data class AppUser(
    val id: String? = null,
    val secret: String? = null
)
