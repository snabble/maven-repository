package io.snabble.network.core.token.domain

data class Token(
    val id: String,
    val value: String,
    val issuedAt: Long,
    val expiresAt: Long
)
