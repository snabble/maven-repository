package io.snabble.network.core.authheader.di

import io.snabble.network.core.authheader.data.AuthHeaderValueRepositoryImpl
import io.snabble.network.core.authheader.domain.AuthHeaderValueRepository
import org.koin.core.module.dsl.factoryOf
import org.koin.dsl.bind
import org.koin.dsl.module

val authHeaderModule = module {
    factoryOf(::AuthHeaderValueRepositoryImpl) bind AuthHeaderValueRepository::class
}
