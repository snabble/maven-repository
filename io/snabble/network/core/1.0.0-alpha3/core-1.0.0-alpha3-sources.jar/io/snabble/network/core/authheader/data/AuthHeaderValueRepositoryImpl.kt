package io.snabble.network.core.authheader.data

import io.snabble.network.core.appuser.domain.AppUser
import io.snabble.network.core.authheader.domain.AuthHeaderValueRepository
import okhttp3.Headers
import java.io.UnsupportedEncodingException
import java.time.Duration
import java.time.Instant
import java.util.Base64

internal class AuthHeaderValueRepositoryImpl : AuthHeaderValueRepository {

    private var serverTimeOffset: Duration = Duration.ZERO

    override suspend fun getValueForTokensEndpoint(appId: String, user: AppUser, secret: String): String? {
        val tOtp = generateTotp(time = getServerSyncedTime(), secret = secret) ?: return null

        val authString = "$appId:$tOtp:${user.id}:${user.secret}"

        return encodeBase64(authString)
    }

    override suspend fun getValueForUsersEndpoint(appId: String, secret: String): String? {
        val tOtp = generateTotp(time = getServerSyncedTime(), secret = secret) ?: return null

        val authString = "$appId:$tOtp"

        return encodeBase64(authString)
    }

    override fun invalidateTimeOffset() {
        serverTimeOffset = Duration.ZERO
    }

    override fun getServerTimeOffset(): Duration = serverTimeOffset

    private fun getServerSyncedTime(): Instant = Instant.now() + serverTimeOffset

    override fun updateServerTimeOffset(serverTime: Instant?) {
        serverTime ?: return
        serverTimeOffset = Duration.between(serverTime, Instant.now())
    }

    private fun generateTotp(time: Instant, secret: String): String? {
        return try {
            val secretData = Base32Encoder.decode(secret) ?: return null
            val timeOtp = Totp(H_MAC_SHA_256, secretData, LENGTH, TIME_STEPS)
            timeOtp.generate(time)
        } catch (e: Base32Encoder.DecodingException) {
            println(e.localizedMessage)
            null
        }
    }

    private fun encodeBase64(string: String): String? {
        return try {
            val base64 = Base64.getEncoder().encodeToString(string.trim().toByteArray(Charsets.UTF_8))
            "Basic $base64"
        } catch (e: UnsupportedEncodingException) {
            println(e.localizedMessage)
            null
        }
    }

    companion object {

        private const val H_MAC_SHA_256 = "HmacSHA256"
        private const val TIME_STEPS = 30
        private const val LENGTH = 8
    }
}

val Headers.serverTime: Instant? get() = getInstant("Date")
