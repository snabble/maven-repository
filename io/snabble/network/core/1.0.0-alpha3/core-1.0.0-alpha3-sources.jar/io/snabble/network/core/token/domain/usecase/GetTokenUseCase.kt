package io.snabble.network.core.token.domain.usecase

import io.snabble.network.core.appuser.domain.usecase.GetAppUserUseCase
import io.snabble.network.core.credentials.domain.usecase.CreateCredentialsUseCase
import io.snabble.network.core.token.domain.Token
import io.snabble.network.core.token.domain.TokenRepository

fun interface GetTokenUseCase {

    suspend operator fun invoke(): Token?
}

internal class GetTokenUseCaseImpl(
    private val tokenRepository: TokenRepository,
    private val getAppUser: GetAppUserUseCase,
    private val createCredentials: CreateCredentialsUseCase
) : GetTokenUseCase {

    override suspend fun invoke(): Token? {
        val token = tokenRepository.getToken()
        return if (token.isInValid()) {
            when (val user = getAppUser()) {
                null -> {
                    val credentials = createCredentials() ?: return null
                    tokenRepository.saveToken(credentials.token)
                    credentials.token
                }

                else -> tokenRepository.fetchNewToken(isRetry = false, user = user)
            }
        } else {
            token
        }
    }

    private suspend fun Token?.isInValid(): Boolean {
        this ?: return true
        return tokenRepository.validateToken(token = this)
    }
}
