package io.snabble.network.core.appuser.domain.usecase

import io.snabble.network.core.appuser.domain.AppUser

fun interface SaveAppUserUseCase : (AppUser) -> Unit
