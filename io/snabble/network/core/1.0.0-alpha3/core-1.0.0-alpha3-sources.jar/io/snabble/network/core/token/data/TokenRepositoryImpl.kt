package io.snabble.network.core.token.data

import io.snabble.network.api.service.TokensService
import io.snabble.network.core.Config
import io.snabble.network.core.appuser.domain.AppUser
import io.snabble.network.core.authheader.data.serverTime
import io.snabble.network.core.authheader.domain.AuthHeaderValueRepository
import io.snabble.network.core.credentials.data.toToken
import io.snabble.network.core.token.domain.Token
import io.snabble.network.core.token.domain.TokenRepository

internal class TokenRepositoryImpl(
    private val tokensService: TokensService,
    private val config: Config,
    private val authHeaderValueRepository: AuthHeaderValueRepository
) : TokenRepository {

    private var cachedToken: Token? = null

    override fun getToken(): Token? = cachedToken

    override fun saveToken(token: Token) {
        cachedToken = token
    }

    override suspend fun fetchNewToken(isRetry: Boolean, user: AppUser): Token? {
        val projectId: String = config.projectId
        val appId: String = config.appId
        val secret: String = config.appSecret

        val authHeader: String = authHeaderValueRepository
            .getValueForTokensEndpoint(appId = appId, user = user, secret = secret) ?: return null

        val response = tokensService.getToken(authHeader, projectId)

        return if (!response.isSuccessful && !isRetry) {
            fetchNewToken(isRetry = true, user)
        } else {
            authHeaderValueRepository.updateServerTimeOffset(response.headers().serverTime)
            response.body()?.toToken()?.also { cachedToken = it }
        }
    }

    override suspend fun validateToken(token: Token): Boolean {
        val tokenValidityTime = (token.expiresAt - token.issuedAt)
        val invalidAt = token.issuedAt + tokenValidityTime / 2
        return authHeaderValueRepository.getServerTimeOffset().toMillis() >= invalidAt
    }

    override fun invalidateToken() {
        cachedToken = null
        authHeaderValueRepository.invalidateTimeOffset()
    }
}
