package io.snabble.network.core.token.domain

import io.snabble.network.core.appuser.domain.AppUser

internal interface TokenRepository {

    fun getToken(): Token?

    fun saveToken(token: Token)

    suspend fun fetchNewToken(isRetry: Boolean, user: AppUser): Token?

    suspend fun validateToken(token: Token): Boolean

    fun invalidateToken()
}
