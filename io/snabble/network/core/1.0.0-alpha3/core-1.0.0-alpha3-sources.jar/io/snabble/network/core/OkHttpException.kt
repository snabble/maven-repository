package io.snabble.network.core

import java.lang.Exception

data class OkHttpException(override val message: String?) : Exception()
