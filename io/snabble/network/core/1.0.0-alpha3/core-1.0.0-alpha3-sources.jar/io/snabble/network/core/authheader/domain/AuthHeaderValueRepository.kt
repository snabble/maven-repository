package io.snabble.network.core.authheader.domain

import io.snabble.network.core.appuser.domain.AppUser
import java.time.Duration
import java.time.Instant

internal interface AuthHeaderValueRepository {

    suspend fun getValueForTokensEndpoint(appId: String, user: AppUser, secret: String): String?

    suspend fun getValueForUsersEndpoint(appId: String, secret: String): String?

    fun invalidateTimeOffset()

    fun getServerTimeOffset(): Duration

    fun updateServerTimeOffset(serverTime: Instant?)
}
