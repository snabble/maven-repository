package io.snabble.network.result.error

sealed interface SnabbleError
