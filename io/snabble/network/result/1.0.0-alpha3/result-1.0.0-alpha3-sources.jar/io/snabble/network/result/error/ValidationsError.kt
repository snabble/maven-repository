package io.snabble.network.result.error

data class ValidationsError(
    val errors: List<ValidationError>
) : SnabbleError

data class ValidationError(
    val field: String,
    val category: String
)
