package io.snabble.network.result.error

data class StructuredError(
    val type: String,
    val message: String
) : SnabbleError
