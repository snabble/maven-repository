package io.snabble.network.result.error

data object UnknownError : SnabbleError
data object ResultProcessingError : SnabbleError
