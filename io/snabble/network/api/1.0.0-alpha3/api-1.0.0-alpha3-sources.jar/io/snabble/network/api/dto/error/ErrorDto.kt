package io.snabble.network.api.dto.error

interface ErrorDto
