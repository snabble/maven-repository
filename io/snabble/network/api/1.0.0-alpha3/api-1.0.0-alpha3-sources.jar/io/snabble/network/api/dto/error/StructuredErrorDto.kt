package io.snabble.network.api.dto.error

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class StructuredErrorDto(
    @SerialName("type") val type: String,
    @SerialName("message") val message: String
) : ErrorDto
