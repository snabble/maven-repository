package io.snabble.network.api.converter.kotlinx.serialization

import com.google.gson.TypeAdapter
import kotlinx.serialization.DeserializationStrategy
import kotlinx.serialization.KSerializer
import kotlinx.serialization.SerialFormat
import kotlinx.serialization.SerializationStrategy
import kotlinx.serialization.StringFormat
import kotlinx.serialization.serializer
import okhttp3.MediaType
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.ResponseBody
import java.lang.reflect.Type

internal sealed class Serializer {

    abstract fun <T> fromResponseBody(
        loader: DeserializationStrategy<T>,
        body: ResponseBody,
        adapter: TypeAdapter<out Any>
    ): T

    abstract fun <T> toRequestBody(contentType: MediaType, saver: SerializationStrategy<T>, value: T): RequestBody

    protected abstract val format: SerialFormat

    fun serializerFor(type: Type): KSerializer<Any> = format.serializersModule.serializer(type)

    class FromString(override val format: StringFormat, val onFailure: OnDeserializingFailed) : Serializer() {

        override fun <T> fromResponseBody(
            loader: DeserializationStrategy<T>,
            body: ResponseBody,
            adapter: TypeAdapter<out Any>
        ): T {
            val string = body.string()
            try {
                return format.decodeFromString(loader, string)
            } catch (e: IllegalArgumentException) {
                onFailure(e)
                @Suppress("UNCHECKED_CAST")
                return adapter.fromJson(string) as T
            }
        }

        override fun <T> toRequestBody(contentType: MediaType, saver: SerializationStrategy<T>, value: T): RequestBody {
            val string = format.encodeToString(saver, value)
            return string.toRequestBody(contentType)
        }
    }
}
