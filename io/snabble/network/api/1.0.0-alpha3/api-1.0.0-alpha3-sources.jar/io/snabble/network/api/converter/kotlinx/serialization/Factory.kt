@file:JvmName("KotlinSerializationConverterFactory")

package io.snabble.network.api.converter.kotlinx.serialization

import com.google.gson.Gson
import com.google.gson.TypeAdapter
import com.google.gson.reflect.TypeToken
import io.snabble.network.api.converter.kotlinx.serialization.Serializer.FromString
import kotlinx.serialization.StringFormat
import okhttp3.MediaType
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Converter
import retrofit2.Retrofit
import java.lang.reflect.Type

internal class Factory(
    private val contentType: MediaType,
    private val serializer: Serializer,
    private val gson: Gson
) : Converter.Factory() {

    @Suppress("RedundantNullableReturnType") // Retaining interface contract.
    override fun responseBodyConverter(
        type: Type,
        annotations: Array<out Annotation>,
        retrofit: Retrofit
    ): Converter<ResponseBody, *>? {
        val loader = serializer.serializerFor(type)
        val adapter: TypeAdapter<out Any> = gson.getAdapter(TypeToken.get(type))
        return DeserializationStrategyConverter(loader, serializer, adapter)
    }

    @Suppress("RedundantNullableReturnType") // Retaining interface contract.
    override fun requestBodyConverter(
        type: Type,
        parameterAnnotations: Array<out Annotation>,
        methodAnnotations: Array<out Annotation>,
        retrofit: Retrofit
    ): Converter<*, RequestBody>? {
        val saver = serializer.serializerFor(type)
        return SerializationStrategyConverter(contentType, saver, serializer)
    }
}

typealias OnDeserializingFailed = (e: IllegalArgumentException) -> Unit

/**
 * Return a [Converter.Factory] which uses Kotlin serialization for string-based payloads.
 *
 * Because Kotlin serialization is so flexible in the types it supports, this converter assumes
 * that it can handle all types. If you are mixing this with something else, you must add this
 * instance last to allow the other converters a chance to see their types.
 */
@JvmName("create")
fun StringFormat.asConverterFactory(
    contentType: MediaType,
    onFailure: OnDeserializingFailed,
    gson: Gson
): Converter.Factory = Factory(contentType, FromString(format = this, onFailure), gson)
