package io.snabble.network.api.converter.kotlinx.serialization

import com.google.gson.TypeAdapter
import kotlinx.serialization.DeserializationStrategy
import okhttp3.ResponseBody
import retrofit2.Converter

internal class DeserializationStrategyConverter<T>(
    private val loader: DeserializationStrategy<T>,
    private val serializer: Serializer,
    private val adapter: TypeAdapter<out Any>
) : Converter<ResponseBody, T> {

    override fun convert(value: ResponseBody) = serializer.fromResponseBody(loader, value, adapter)
}
