package io.snabble.network.api.service

import io.snabble.network.api.dto.TokenDto
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

interface TokensService {

    @GET("/tokens")
    suspend fun getToken(
        @Header("Authorization") header: String,
        @Query("project") projectId: String,
        @Query("role") role: String = "retailerApp"
    ): Response<TokenDto>
}
