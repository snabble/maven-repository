package io.snabble.network.api.service

import io.snabble.network.api.dto.CredentialsDto
import retrofit2.Response
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface UsersService {

    @POST("/apps/{appId}/users")
    suspend fun createCredentials(
        @Header("Authorization") header: String,
        @Path("appId") appId: String,
        @Query("project") projectId: String
    ): Response<CredentialsDto>
}
