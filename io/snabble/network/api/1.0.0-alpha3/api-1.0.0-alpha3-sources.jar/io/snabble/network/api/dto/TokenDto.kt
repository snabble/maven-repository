package io.snabble.network.api.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class TokenDto(
    @SerialName("id") val id: String,
    @SerialName("token") val value: String,
    @SerialName("issuedAt") val issuedAt: Long,
    @SerialName("expiresAt") val expiresAt: Long
)
