package io.snabble.network.api.retrofit

import io.snabble.network.api.dto.error.ErrorDto
import io.snabble.network.api.dto.error.StructuredErrorDto
import io.snabble.network.api.dto.error.ValidationsErrorDto
import io.snabble.network.result.error.SnabbleError
import io.snabble.network.result.error.StructuredError
import io.snabble.network.result.error.UnknownError
import io.snabble.network.result.error.ValidationError
import io.snabble.network.result.error.ValidationsError
import kotlinx.serialization.SerializationException
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import okhttp3.Request
import okio.Timeout
import retrofit2.Call
import retrofit2.Callback
import retrofit2.HttpException
import retrofit2.Response
import java.io.IOException

internal class ApiResultCall<T : Any>(
    private val delegate: Call<T>,
    private val json: Json
) : Call<ApiResponse<T>> {

    override fun clone(): Call<ApiResponse<T>> = ApiResultCall(delegate.clone(), json)

    override fun execute(): Response<ApiResponse<T>> = throw NotImplementedError()

    override fun enqueue(callback: Callback<ApiResponse<T>>) {
        delegate.enqueue(object : Callback<T> {

            override fun onResponse(call: Call<T>, response: Response<T>) {
                val apiResponse = when {
                    response.isSuccessful -> response.toSuccessResponse()
                    else -> response.toErrorResponse(json)
                }
                callback.onResponse(
                    this@ApiResultCall,
                    Response.success(apiResponse)
                )
            }

            override fun onFailure(call: Call<T>, exception: Throwable) {
                val message: String? = when (exception) {
                    is IOException -> "No internet connection"
                    else -> exception.localizedMessage
                }
                val fail: ApiResponse<T> = Failure(
                    exception = exception,
                    rawMessage = message,
                    error = UnknownError
                )
                callback.onResponse(this@ApiResultCall, Response.success(fail))
            }
        })
    }

    override fun isExecuted(): Boolean = delegate.isExecuted

    override fun cancel() = delegate.cancel()

    override fun isCanceled(): Boolean = delegate.isCanceled

    override fun request(): Request = delegate.request()

    override fun timeout(): Timeout = delegate.timeout()
}

internal fun <T : Any> Response<T>.toSuccessResponse(): ApiResponse<T> {
    val body = body()
    return when {
        body != null -> Success(response = this, data = body)
        else -> SuccessNoContent(response = this)
    }
}

internal fun <T : Any> Response<in T>.toErrorResponse(json: Json): Failure {
    val errorBody = errorBody()?.string()
    val error = try {
        when {
            code() != INVALID_REQUEST -> errorBody?.let<String, StructuredErrorDto>(json::decodeFromString)
            else -> errorBody?.let<String, ValidationsErrorDto>(json::decodeFromString)
        }
    } catch (ignored: SerializationException) {
        null
    }

    return Failure(
        error = error.toSnabbleError(),
        rawMessage = errorBody,
        exception = HttpException(this)
    )
}

const val INVALID_REQUEST = 422

fun ErrorDto?.toSnabbleError(): SnabbleError = when (this) {
    is ValidationsErrorDto -> toValidationsError()
    is StructuredErrorDto -> toStructuredError()
    else -> UnknownError
}

private fun StructuredErrorDto.toStructuredError() = StructuredError(type = type, message = message)

private fun ValidationsErrorDto.toValidationsError() = ValidationsError(
    errors = errors.map { ValidationError(field = it.field, category = it.category) }
)
