package io.snabble.network.api.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class CredentialsDto(
    @SerialName("token") val tokenDto: TokenDto,
    @SerialName("appUser") val appUserDto: AppUserDto
)
