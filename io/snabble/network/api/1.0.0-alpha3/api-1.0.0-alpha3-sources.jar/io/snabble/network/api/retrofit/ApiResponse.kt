package io.snabble.network.api.retrofit

import io.snabble.network.result.error.SnabbleError
import retrofit2.Response

sealed interface ApiResponse<out T : Any>

data class Success<T : Any>(
    val data: T,
    val response: Response<T>
) : ApiResponse<T>

data class SuccessNoContent(val response: Response<*>) : ApiResponse<Nothing>

data class Failure(
    val error: SnabbleError,
    val rawMessage: String? = null,
    val exception: Throwable
) : ApiResponse<Nothing>
