package io.snabble.network.api.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class AppUserDto(
    @SerialName("id") val id: String? = null,
    @SerialName("secret") val secret: String? = null
)
