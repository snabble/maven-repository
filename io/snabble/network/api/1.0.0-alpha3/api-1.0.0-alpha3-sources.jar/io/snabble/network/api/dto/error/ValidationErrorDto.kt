package io.snabble.network.api.dto.error

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ValidationsErrorDto(
    @SerialName("validationErrors") val errors: List<ValidationErrorDto>
) : ErrorDto

@Serializable
data class ValidationErrorDto(
    @SerialName("field") val field: String,
    @SerialName("category") val category: String
)
