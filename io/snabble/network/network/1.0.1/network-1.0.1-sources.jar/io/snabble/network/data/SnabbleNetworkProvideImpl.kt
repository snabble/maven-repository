package io.snabble.network.data

import io.snabble.network.core.appuser.domain.AppUser
import io.snabble.network.core.appuser.domain.usecase.SaveAppUserUseCase
import io.snabble.network.core.token.domain.usecase.InvalidateTokenUseCase
import io.snabble.network.domain.SnabbleNetworkProvider
import okhttp3.OkHttpClient
import retrofit2.Retrofit

internal data class SnabbleNetworkProvideImpl(
    override val okHttpClient: OkHttpClient,
    override val retrofit: Retrofit,
    private val saveAppUser: SaveAppUserUseCase,
    private val invalidateToken: InvalidateTokenUseCase
) : SnabbleNetworkProvider {

    override fun setNewAppUser(id: String, secret: String) {
        saveAppUser(AppUser(id, secret))
        invalidateToken()
    }
}
