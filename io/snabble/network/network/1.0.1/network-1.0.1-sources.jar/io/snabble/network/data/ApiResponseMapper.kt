package io.snabble.network.data

import io.snabble.network.api.retrofit.ApiResponse
import io.snabble.network.api.retrofit.Failure
import io.snabble.network.api.retrofit.Success
import io.snabble.network.api.retrofit.SuccessNoContent
import io.snabble.network.result.Result
import io.snabble.network.result.error.UnknownError

fun <T : Any, R> ApiResponse<T>.toResult(mapper: (T) -> R): Result<R> = when (this) {
    is Success -> {
        Result.success(mapper(data))
    }

    is SuccessNoContent -> {
        Result.failure(
            exception = IllegalStateException("Received unexpected 204 NO CONTENT"),
            error = UnknownError
        )
    }

    is Failure -> {
        Result.failure(exception, error = error)
    }
}

fun <T : Any, R> ApiResponse<T>.toNullableResult(mapper: (T) -> R): Result<R?> = when (this) {
    is Success -> {
        Result.success(mapper(data))
    }

    is SuccessNoContent -> {
        Result.success(null)
    }

    is Failure -> {
        Result.failure(exception, error = error)
    }
}
