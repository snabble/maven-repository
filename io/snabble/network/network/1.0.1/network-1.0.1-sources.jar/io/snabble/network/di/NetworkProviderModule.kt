package io.snabble.network.di

import io.snabble.network.api.retrofit.ApiResultCallAdapterFactory
import io.snabble.network.core.di.BASE_URL
import io.snabble.network.core.di.RETROFIT_JSON_CONVERTER_FACTORY
import okhttp3.OkHttpClient
import org.koin.core.qualifier.named
import org.koin.dsl.bind
import org.koin.dsl.module
import retrofit2.Retrofit

internal val networkProviderModule = module {

    single {
        Retrofit.Builder()
            .client(get())
            .addConverterFactory(get(named(RETROFIT_JSON_CONVERTER_FACTORY)))
            .addCallAdapterFactory(get<ApiResultCallAdapterFactory>())
            .baseUrl(get<String>(named(BASE_URL)))
            .build()
    } bind Retrofit::class

    factory {
        OkHttpClient.Builder()
            .addInterceptor(interceptor = get())
            .build()
    } bind OkHttpClient::class
}
