package io.snabble.network.data

import io.snabble.network.api.dto.error.StructuredErrorDto
import io.snabble.network.api.dto.error.ValidationsErrorDto
import io.snabble.network.api.retrofit.INVALID_REQUEST
import io.snabble.network.api.retrofit.toSnabbleError
import io.snabble.network.result.Result
import io.snabble.network.result.error.ResultProcessingError
import io.snabble.network.result.error.SnabbleError
import io.snabble.network.result.error.UnknownError
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume

suspend inline fun <reified T> OkHttpClient.getResult(
    request: Request,
    json: Json
): Result<T> =
    suspendCancellableCoroutine { continuation ->
        val call = newCall(request)
        call.enqueue(object : Callback {

            override fun onFailure(call: Call, e: IOException) {
                continuation.resume(Result.failure(exception = e, error = UnknownError))
            }

            override fun onResponse(call: Call, response: Response) {
                when {
                    response.isSuccessful -> continuation.resume(response.toResult(json))

                    else -> {
                        continuation.resume(
                            Result.failure(
                                exception = OkHttpException("0" + response.message),
                                error = response.toErrorResponse(json)
                            )
                        )
                    }
                }
            }
        })

        continuation.invokeOnCancellation { call.cancel() }
    }

inline fun <reified T> Response.toResult(json: Json): Result<T> {
    val result: DecodingResult<T?> = toSuccessResponse<T>(json)
    return when {
        result.result != null -> Result.success(result.result)

        result.exception != null -> {
            Result.failure(
                exception = result.exception,
                error = ResultProcessingError
            )
        }

        else -> {
            Result.failure(
                exception = OkHttpException(message),
                error = UnknownError
            )
        }
    }
}

suspend inline fun <reified T> OkHttpClient.getNullableResult(
    request: Request,
    json: Json
): Result<T?> = suspendCancellableCoroutine { continuation ->
    val call = newCall(request)
    call.enqueue(object : Callback {

        override fun onFailure(call: Call, e: IOException) {
            continuation.resume(Result.failure(e, error = UnknownError))
        }

        override fun onResponse(call: Call, response: Response) {
            when {
                response.isSuccessful -> {
                    val result: T? = response.toSuccessResponse<T>(json).result
                    continuation.resume(Result.success(result))
                }

                else -> {
                    continuation.resume(
                        Result.failure(
                            exception = OkHttpException("2" + response.message),
                            error = response.toErrorResponse(json)
                        )
                    )
                }
            }
        }
    })

    continuation.invokeOnCancellation { call.cancel() }
}

inline fun <reified T> Response.toSuccessResponse(json: Json): DecodingResult<T?> = try {
    val result: T? = body?.string()?.let(json::decodeFromString)
    DecodingResult(result, null)
} catch (exception: SerializationException) {
    DecodingResult(null, exception)
} catch (exception: IllegalArgumentException) {
    DecodingResult(null, exception)
}

data class DecodingResult<T>(val result: T?, val exception: Exception?)

fun Response.toErrorResponse(json: Json): SnabbleError = try {
    when {
        code != INVALID_REQUEST -> body?.string()?.let<String, StructuredErrorDto> { json.decodeFromString(it) }
        else -> body?.string()?.let<String, ValidationsErrorDto>(json::decodeFromString)
    }
} catch (exception: SerializationException) {
    StructuredErrorDto("SerializationException", "${exception.message}")
} catch (exception: IllegalArgumentException) {
    StructuredErrorDto("IllegalArgumentException", "${exception.message}")
}.toSnabbleError()
