package io.snabble.network.domain

import io.snabble.network.data.NetworkConfig
import io.snabble.network.data.SnabbleNetworkProvideImpl
import okhttp3.OkHttpClient
import retrofit2.Retrofit

interface SnabbleNetworkProvider {

    /**
     * Provides an [OkHttpClient] with required features for the snabble network layer, e.g.
     * authorization and creation of a new app user if no credentials are provided in the [NetworkConfig] init block
     *
     * @return OkhttpClient with authorization layer
     */
    val okHttpClient: OkHttpClient

    /**
     * Provides an [Retrofit] instance using the [SnabbleNetworkProvider.getOkHttpClient].
     *
     * @return Retrofit instance with authorization layer
     */
    val retrofit: Retrofit

    /**
     * Set new app user credentials. The new credentials overrides the ones set in the [NetworkConfig] earlier.
     * The topken will be invalidated and a new one will be fetched with the new credentials.
     */
    fun setNewAppUser(id: String, secret: String)

    companion object {

        /**
         * Builder function to create an instance of [SnabbleNetworkProvider].
         *
         * Here is a sample of how to use this function:
         *
         * ```
         * val network: NetworkProvider = NetworkProvider.getInstance {
         *     baseUrl = https://api.snabble-staging.io
         *     projectId = "demo-project-123"
         *     appId = "demo-app-123"
         *     appSecret = "BAGEKFSN$323FDFJ..."
         *
         *     onNewAppCredentialsCallback =
         *         SnabblePhoneAuthAppCredentialsCallback { id: String, secret: String ->
         *             sharedPreferences.saveAppCredentials(id, secret)
         *         }
         *
         *     val (id, secret) = sharedPreferences.getAppCredentials() ?: return@snabblePhoneAuth
         *
         *     appIdentifier = id
         *     appSecret = secret
         * }
         * ```
         *
         * @param init The init block to create a [NetworkConfig] for the [SnabbleNetworkProvider]
         *
         * @return An instance of [SnabbleNetworkProvider] using the configuration from the [init] block
         *
         */
        fun getInstance(
            config: NetworkConfig
        ): SnabbleNetworkProvider = with(config.koin) {
            SnabbleNetworkProvideImpl(
                okHttpClient = get(),
                retrofit = get(),
                saveAppUser = get(),
                invalidateToken = get()
            )
        }
    }
}
