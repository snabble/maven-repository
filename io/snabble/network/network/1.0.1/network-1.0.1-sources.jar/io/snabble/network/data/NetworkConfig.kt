package io.snabble.network.data

import io.snabble.network.api.converter.kotlinx.serialization.OnDeserializingFailed
import io.snabble.network.core.Config
import io.snabble.network.core.appuser.di.appUserModule
import io.snabble.network.core.appuser.domain.AppUser
import io.snabble.network.core.authheader.di.authHeaderModule
import io.snabble.network.core.credentials.di.credentialsModule
import io.snabble.network.core.di.coreModule
import io.snabble.network.core.token.di.tokenModule
import io.snabble.network.di.networkProviderModule
import io.snabble.network.domain.AppCredentialsCallback
import kotlinx.coroutines.flow.Flow
import org.koin.core.Koin
import org.koin.dsl.bind
import org.koin.dsl.koinApplication
import org.koin.dsl.module

data class NetworkConfig(
    /**
     * Individual secret of the current checked in project
     */
    override val projectId: String,

    /**
     * Individual identifier of the current application
     */
    override val appId: String,

    /**
     * Secret needed for authentication
     */
    override val appSecret: String,

    /**
     * Individual identifier for an app user
     *
     * Alternatively an [appUserFlow] can be provided
     */
    val userId: String? = null,

    /**
     * Individual secret for the [userId]
     *
     * Alternatively an [appUserFlow] can be provided
     */
    val userSecret: String? = null,

    /**
     * A flow of [AppUser]s can be provided to have the library automatically update to the latest app user.
     */
    override val appUserFlow: Flow<AppUser?>?,

    /**
     * The base url for Snabble Network, the default url is the one for testing.
     *
     * Available Environments:
     * * production - _https://api.snabble.io_
     * * staging - _https://api.snabble-staging.io_
     * * testing - _https://api.snabble-testing.io_
     *
     */
    override val baseUrl: String = "https://api.snabble-testing.io",

    /**
     * The app credentials callback, required to safe a new generated app user.
     * Normally this call is only fired once (on the first usage) and the credentials should
     * be stored to restore the app user
     */
    override val onNewAppCredentialsCallback: AppCredentialsCallback? = null,

    /**
     * If deserializing using Kotlin Serialization JSON parser fails, e.g. if a not optional value is missing,
     * the GSON parser is used. Historically GSON has been used and due to its reflection based implementation it's
     * unaware of Kotlin's null-safety. The callback should be used to report Kotlin Serialization JSON parsing issues
     * to get rid of GSON in the long-term.
     */
    override val onDeserializingFailed: OnDeserializingFailed

) : Config {

    override val appCredentials: AppUser? =
        if (userId != null && userSecret != null) AppUser(id = userId, secret = userSecret) else null

    internal lateinit var koin: Koin

    init {
        setupDi()
    }

    private fun setupDi() {
        val koinApplication = koinApplication {
            modules(
                appUserModule,
                coreModule,
                credentialsModule,
                networkProviderModule,
                authHeaderModule,
                tokenModule,
                module {
                    single { this@NetworkConfig } bind Config::class
                }
            )
        }
        koin = koinApplication.koin
    }
}
