package io.snabble.network.domain

import io.snabble.network.core.CredentialsCallback

/**
 * Callback for a new app user. This callback is only called if no
 * [NetworkConfig.userId] and no [NetworkConfig.userSecret] has been
 * provided.
 *
 * To make use of this callback set it in the builder functions
 * [io.snabble.network.NetworkProvider.Companion.getInstance] init block.
 *
 * **CAUTION:** Save the credentials provided through this callback to restore an app/user after the
 * [SnabbleNetworkProvider] instance has been destroyed.
 *
 */
fun interface AppCredentialsCallback : CredentialsCallback {

    /**
     * @param appId A new app identifier for the current app instance.
     * @param appSecret The secret for the new appId.
     */
    override fun onNewAppUser(appId: String, appSecret: String)
}
