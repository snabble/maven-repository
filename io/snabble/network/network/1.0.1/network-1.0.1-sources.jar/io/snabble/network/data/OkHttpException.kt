package io.snabble.network.data

import java.lang.Exception

data class OkHttpException(override val message: String?) : Exception()
