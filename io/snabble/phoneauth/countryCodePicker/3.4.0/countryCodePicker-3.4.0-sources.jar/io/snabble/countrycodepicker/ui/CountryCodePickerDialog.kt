package io.snabble.countrycodepicker.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import io.snabble.countrycodepicker.di.countryCodePickerModule
import io.snabble.countrycodepicker.ui.widget.CountryPickerDialog
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.filterNotNull
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.compose.koinViewModel
import org.koin.compose.KoinIsolatedContext
import org.koin.dsl.koinApplication

@Composable
fun CountryCodePickerDialog(
    initialCallingCode: String? = null,
    showDialog: Boolean,
    onCountrySelected: (callingCode: String, flagEmoji: String) -> Unit,
    onDismissRequest: () -> Unit,
) {
    val context = LocalContext.current
    KoinIsolatedContext(
        context =
            koinApplication {
                androidContext(context.applicationContext)

                modules(countryCodePickerModule)
            }
    ) {
        val koinViewModel = koinViewModel<CountryPickerViewModel>()
        LaunchedEffect(key1 = Unit) {
            initialCallingCode?.let(koinViewModel::setInitialCountry)
            koinViewModel.selectedCountry
                .filterNotNull()
                .collectLatest { (_, callingCode, _, flagEmoji) ->
                    onCountrySelected(callingCode, flagEmoji)
                }
        }

        if (showDialog) CountryPickerDialog(onDismissRequest = onDismissRequest)
    }
}
