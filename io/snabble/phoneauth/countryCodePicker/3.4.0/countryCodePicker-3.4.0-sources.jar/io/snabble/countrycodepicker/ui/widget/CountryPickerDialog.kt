package io.snabble.countrycodepicker.ui.widget

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import io.snabble.countrycodepicker.R
import io.snabble.countrycodepicker.ui.CountryPickerViewModel
import org.koin.androidx.compose.koinViewModel

@Composable
internal fun CountryPickerDialog(
    viewModel: CountryPickerViewModel = koinViewModel(),
    onCountrySelected: ((countryCode: String, flag: String) -> Unit)? = null,
    onDismissRequest: () -> Unit,
) {
    val countries = viewModel.countries.collectAsState().value
    val selectedCountry = viewModel.selectedCountry.collectAsState().value

    if (countries == null || selectedCountry == null) {
        onDismissRequest()
        return
    }

    var searchFieldValue by remember { mutableStateOf("") }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties =
            DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = true
            )
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column {
                Icon(
                    modifier =
                        Modifier
                            .padding(8.dp)
                            .align(Alignment.End)
                            .clickable { onDismissRequest() },
                    imageVector = Icons.Filled.Clear,
                    contentDescription = ""
                )
                Text(
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp),
                    text = stringResource(id = R.string.CountryCode_description),
                    style =
                        MaterialTheme.typography.titleLarge.copy(
                            fontSize = 18.sp
                        ),
                    textAlign = TextAlign.Center
                )
                SearchFieldWidget(
                    modifier = Modifier.padding(8.dp),
                    query = searchFieldValue,
                    onQueryChange = {
                        searchFieldValue = it
                        viewModel.filterCountries(it)
                    }
                )
                HorizontalDivider(
                    thickness = Dp.Hairline,
                    color = Color.LightGray
                )
                val listState = rememberLazyListState()
                LaunchedEffect(key1 = Unit) {
                    listState.scrollToItem(
                        index = countries.indexOf(selectedCountry).coerceAtLeast(0),
                        scrollOffset = (-24).dpInPx
                    )
                }
                LazyColumn(state = listState) {
                    items(countries) {
                        DropdownMenuItem(
                            leadingIcon = {
                                Text(text = it.flagEmoji, fontSize = 22.sp)
                            },
                            text = {
                                Text(
                                    text = it.displayName,
                                    style = MaterialTheme.typography.bodyLarge,
                                    maxLines = 1
                                )
                            },
                            trailingIcon = {
                                Text(
                                    text = it.callingCode,
                                    style = MaterialTheme.typography.bodyLarge,
                                    maxLines = 1
                                )
                            },
                            onClick = {
                                viewModel.updateSelectedCountry(it)
                                onCountrySelected?.invoke(it.callingCode, it.flagEmoji)
                                onDismissRequest()
                            }
                        )
                        HorizontalDivider(
                            thickness = Dp.Hairline,
                            color = Color.LightGray
                        )
                    }
                }
            }
        }
    }
}
