package io.snabble.countrycodepicker.data

import io.snabble.countrycodepicker.data.source.LocalCountriesDataSource
import io.snabble.countrycodepicker.domain.Country
import io.snabble.countrycodepicker.domain.CountryRepository

internal class CountryRepositoryImpl(
    private val localCountriesDataSource: LocalCountriesDataSource,
) : CountryRepository {
    override fun loadCountries(): List<Country>? =
        localCountriesDataSource
            .loadCallingCodes()
            ?.map { (countryCode, callingCode) ->
                Country(
                    displayName = countryCode.displayName,
                    callingCode = callingCode,
                    isoCountryCode = countryCode.value,
                    flagEmoji = countryCode.flagEmoji
                )
            }?.sortedBy { it.displayName }
}
