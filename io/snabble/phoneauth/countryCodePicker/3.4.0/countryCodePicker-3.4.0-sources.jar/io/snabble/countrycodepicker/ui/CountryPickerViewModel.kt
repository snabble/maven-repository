package io.snabble.countrycodepicker.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import io.snabble.countrycodepicker.domain.Country
import io.snabble.countrycodepicker.domain.GetCountriesUseCase
import io.snabble.countrycodepicker.utils.getLocaleOrFirst
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal class CountryPickerViewModel(
    getCountries: GetCountriesUseCase,
    private val ioDispatcher: CoroutineDispatcher,
) : ViewModel() {
    private val countryList = getCountries()

    private val _countries = MutableStateFlow(countryList)
    val countries: StateFlow<List<Country>?> = _countries.asStateFlow()

    private val _selectedCountry = MutableStateFlow(countries.value?.getLocaleOrFirst())
    val selectedCountry: StateFlow<Country?> = _selectedCountry.asStateFlow()

    private var filterJob: Job? = null

    fun filterCountries(string: String) {
        filterJob?.cancel()
        filterJob =
            viewModelScope.launch {
                val filteredCountries = filterMatchingCountries(string)
                _countries.update { filteredCountries }
            }
    }

    fun setInitialCountry(callingCode: String) {
        countryList
            ?.find { it.callingCode == callingCode }
            ?.let { updateSelectedCountry(it) }
    }

    fun updateSelectedCountry(country: Country) {
        _selectedCountry.update { country }
    }

    private suspend fun filterMatchingCountries(string: String) =
        withContext(ioDispatcher) {
            countryList?.filter { country: Country -> country.displayName.startsWith(string, true) }
        }
}
