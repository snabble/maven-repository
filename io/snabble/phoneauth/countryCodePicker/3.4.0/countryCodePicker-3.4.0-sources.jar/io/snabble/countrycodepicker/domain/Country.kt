package io.snabble.countrycodepicker.domain

data class Country(
    val displayName: String,
    val callingCode: String,
    val isoCountryCode: String,
    val flagEmoji: String,
)
