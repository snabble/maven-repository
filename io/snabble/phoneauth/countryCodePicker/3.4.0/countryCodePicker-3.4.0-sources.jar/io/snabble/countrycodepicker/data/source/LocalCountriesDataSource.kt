package io.snabble.countrycodepicker.data.source

import io.snabble.countrycodepicker.data.CountryDto

internal interface LocalCountriesDataSource {
    fun loadCallingCodes(): List<CountryDto>?
}
