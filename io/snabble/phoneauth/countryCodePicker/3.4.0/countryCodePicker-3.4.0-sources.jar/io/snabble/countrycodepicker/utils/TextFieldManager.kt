package io.snabble.countrycodepicker.utils

import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.platform.SoftwareKeyboardController

internal class TextFieldManager(
    private val focusManager: FocusManager,
    private val keyboardController: SoftwareKeyboardController?,
) {
    fun clearFocusAndHideKeyboard() {
        focusManager.clearFocus()
        keyboardController?.hide()
    }
}
