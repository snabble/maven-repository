package io.snabble.countrycodepicker.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.util.Locale

@Serializable
internal data class CountryDto(
    @SerialName("countryCode") val countryCode: CountryCodeDto,
    @SerialName("internationalCallingCode") val callingCode: String,
)

@Serializable
@JvmInline
internal value class CountryCodeDto(
    val value: String,
) {
    val displayName: String
        get() = Locale("", value).displayName

    val flagEmoji: String
        get() {
            val firstLetter = Character.codePointAt(value, 0) - UNICODE_UPPERCASE_A + REGIONAL_INDICATOR_SYMBOL_LETTER_A
            val secondLetter =
                Character.codePointAt(value, 1) - UNICODE_UPPERCASE_A + REGIONAL_INDICATOR_SYMBOL_LETTER_A
            return String(Character.toChars(firstLetter)) + String(Character.toChars(secondLetter))
        }

    companion object {
        private const val UNICODE_UPPERCASE_A = 0x41
        private const val REGIONAL_INDICATOR_SYMBOL_LETTER_A = 0x1F1E6
    }
}
