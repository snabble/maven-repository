package io.snabble.countrycodepicker.ui.widget

import android.content.res.Resources
import android.util.TypedValue
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import io.snabble.countrycodepicker.ui.CountryPickerViewModel
import org.koin.androidx.compose.koinViewModel

@Composable
internal fun CountryCodePickerWidget(
    modifier: Modifier = Modifier,
    onCountrySelected: (countryCode: String) -> Unit,
    viewModel: CountryPickerViewModel = koinViewModel(),
) {
    val countries = viewModel.countries.collectAsState().value
    val selectedCountry = viewModel.selectedCountry.collectAsState().value

    if (countries == null || selectedCountry == null) return

    // Always return the latest collected selected country
    onCountrySelected(selectedCountry.callingCode)

    var showCountryPickerDialog by remember { mutableStateOf(false) }

    Column(
        modifier =
            Modifier
                .height(56.dp)
                .then(modifier),
        verticalArrangement = Arrangement.Center
    ) {
        SelectedCountryItem(
            modifier =
                Modifier
                    .fillMaxHeight()
                    .clickable { showCountryPickerDialog = !showCountryPickerDialog },
            country = selectedCountry,
            isExpanded = showCountryPickerDialog
        )

        if (showCountryPickerDialog) {
            CountryPickerDialog {
                showCountryPickerDialog = false
            }
        }
    }
}

inline val Number.dpInPx: Int
    get() = dp.toInt()

inline val Number.dp: Float
    get() = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, toFloat(), Resources.getSystem().displayMetrics)
