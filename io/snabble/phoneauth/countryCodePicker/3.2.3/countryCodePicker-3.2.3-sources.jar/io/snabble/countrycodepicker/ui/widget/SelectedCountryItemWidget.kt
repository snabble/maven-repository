package io.snabble.countrycodepicker.ui.widget

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.snabble.countrycodepicker.domain.Country

@Composable
internal fun SelectedCountryItem(modifier: Modifier, country: Country, isExpanded: Boolean) {
    Row(
        modifier = Modifier
            .padding(start = 8.dp)
            .then(modifier),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(text = country.flagEmoji, fontSize = 22.sp)
        Text(
            text = country.callingCode,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .5f),
            overflow = TextOverflow.Ellipsis,
            maxLines = 1
        )
        Icon(
            imageVector = if (isExpanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
            contentDescription = "",
            tint = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Preview(showBackground = true)
@Composable
private fun Preview() {
    SelectedCountryItem(
        modifier = Modifier.padding(16.dp),
        country = Country("", "+123", "DE", "\uD83C\uDDE9\uD83C\uDDEA"),
        isExpanded = false
    )
}
