package io.snabble.countrycodepicker.data.source

import android.content.res.AssetManager
import android.util.Log
import io.snabble.countrycodepicker.data.CountryDto
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import java.io.IOException

internal class LocalCountriesDataSourceImpl(
    private val assetManager: AssetManager,
    private val json: Json,
) : LocalCountriesDataSource {

    private val tag = javaClass.name

    override fun loadCallingCodes(): List<CountryDto>? = try {
        json.decodeFromString<List<CountryDto>>(
            assetManager.open(CALLING_CODES_FILE).reader().readText()
        )
    } catch (e: SerializationException) {
        Log.e(tag, "Loading countries failed: ${e.message}")
        null
    } catch (e: IllegalArgumentException) {
        Log.e(tag, "Loading countries failed: ${e.message}")
        null
    } catch (e: IOException) {
        Log.e(tag, "Loading countries failed: ${e.message}")
        null
    }

    companion object {

        private const val CALLING_CODES_FILE = "internationalCallingCodes.json"
    }
}
