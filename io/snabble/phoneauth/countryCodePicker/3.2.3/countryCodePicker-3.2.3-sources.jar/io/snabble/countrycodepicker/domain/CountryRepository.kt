package io.snabble.countrycodepicker.domain

internal interface CountryRepository {

    fun loadCountries(): List<Country>?
}
