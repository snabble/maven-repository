package io.snabble.countrycodepicker.utils

import io.snabble.countrycodepicker.domain.Country
import java.util.Locale

internal fun List<Country>.getLocaleOrFirst(): Country? =
    firstOrNull { it.isoCountryCode == Locale.getDefault().country } ?: firstOrNull { it.isoCountryCode == "DE" }
