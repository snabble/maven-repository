package io.snabble.countrycodepicker.di

import android.content.res.AssetManager
import io.snabble.countrycodepicker.data.CountryRepositoryImpl
import io.snabble.countrycodepicker.data.source.LocalCountriesDataSource
import io.snabble.countrycodepicker.data.source.LocalCountriesDataSourceImpl
import io.snabble.countrycodepicker.domain.CountryRepository
import io.snabble.countrycodepicker.domain.GetCountriesUseCase
import io.snabble.countrycodepicker.ui.CountryPickerViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.serialization.json.Json
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.dsl.factoryOf
import org.koin.core.module.dsl.viewModelOf
import org.koin.dsl.bind
import org.koin.dsl.module

internal val countryCodePickerModule = module {
    factory { Json { ignoreUnknownKeys = true; isLenient = true } } bind Json::class
    factory { androidContext().assets } bind AssetManager::class
    factory { Dispatchers.IO } bind CoroutineDispatcher::class

    factoryOf(::CountryRepositoryImpl) bind CountryRepository::class
    factoryOf(::LocalCountriesDataSourceImpl) bind LocalCountriesDataSource::class
    factory { GetCountriesUseCase(get<CountryRepository>()::loadCountries) } bind GetCountriesUseCase::class

    viewModelOf(::CountryPickerViewModel)
}
