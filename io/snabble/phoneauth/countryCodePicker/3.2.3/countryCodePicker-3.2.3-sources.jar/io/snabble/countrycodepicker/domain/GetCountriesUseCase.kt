package io.snabble.countrycodepicker.domain

internal fun interface GetCountriesUseCase : () -> List<Country>?
