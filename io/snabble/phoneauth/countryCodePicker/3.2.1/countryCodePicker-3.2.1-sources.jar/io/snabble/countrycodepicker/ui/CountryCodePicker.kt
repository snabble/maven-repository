package io.snabble.countrycodepicker.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import io.snabble.countrycodepicker.di.countryCodePickerModule
import io.snabble.countrycodepicker.ui.widget.CountryCodePickerWidget
import org.koin.android.ext.koin.androidContext
import org.koin.compose.KoinApplication

@Composable
fun CountryCodePicker(
    modifier: Modifier = Modifier,
    onCountryCodeSelected: (countryCode: String) -> Unit,
) {
    val context = LocalContext.current

    KoinApplication(application = {
        modules(countryCodePickerModule)
        androidContext(context.applicationContext)
    }) {
        CountryCodePickerWidget(modifier, onCountryCodeSelected)
    }
}
