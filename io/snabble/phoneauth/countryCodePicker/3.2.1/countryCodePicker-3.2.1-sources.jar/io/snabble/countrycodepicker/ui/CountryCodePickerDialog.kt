package io.snabble.countrycodepicker.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import io.snabble.countrycodepicker.di.countryCodePickerModule
import io.snabble.countrycodepicker.ui.widget.CountryPickerDialog
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.filterNotNull
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.compose.koinViewModel
import org.koin.compose.KoinApplication

@Composable
fun CountryCodePickerDialog(
    showDialog: Boolean,
    onCountrySelected: (callingCode: String, flagEmoji: String) -> Unit,
    onDismissRequest: () -> Unit,
) {
    val context = LocalContext.current

    KoinApplication(
        application = {
            androidContext(context.applicationContext)

            modules(countryCodePickerModule)
        }
    ) {
        val koinViewModel = koinViewModel<CountryPickerViewModel>()
        LaunchedEffect(key1 = Unit) {
            koinViewModel.selectedCountry
                .filterNotNull()
                .collectLatest { (_, callingCode, _, flagEmoji) ->
                    onCountrySelected(callingCode, flagEmoji)
                }
        }

        if (showDialog) CountryPickerDialog(onDismissRequest = onDismissRequest)
    }
}
