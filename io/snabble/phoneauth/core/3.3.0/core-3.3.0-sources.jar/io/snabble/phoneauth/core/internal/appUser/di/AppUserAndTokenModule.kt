package io.snabble.phoneauth.core.internal.appUser.di

import io.snabble.phoneauth.core.di.modules.AUTH_FREE_RETROFIT
import io.snabble.phoneauth.core.internal.appUser.AppUserAndTokenRepository
import io.snabble.phoneauth.core.internal.appUser.AppUserAndTokenRepositoryImpl
import io.snabble.phoneauth.core.internal.appUser.AppUserRepository
import io.snabble.phoneauth.core.internal.appUser.AppUserRepositoryImpl
import io.snabble.phoneauth.core.internal.appUser.SaveAppUserUseCase
import io.snabble.phoneauth.core.internal.appUser.service.AppUserAndTokenService
import io.snabble.phoneauth.core.internal.appUser.service.TokenService
import org.koin.core.module.dsl.singleOf
import org.koin.core.qualifier.named
import org.koin.dsl.bind
import org.koin.dsl.module
import retrofit2.Retrofit

internal val appUserAndTokenModule = module {
    singleOf(::AppUserAndTokenRepositoryImpl) bind AppUserAndTokenRepository::class
    singleOf(::AppUserRepositoryImpl) bind AppUserRepository::class

    single {
        get<Retrofit>(named(AUTH_FREE_RETROFIT)).create(AppUserAndTokenService::class.java)
    } bind AppUserAndTokenService::class

    single {
        get<Retrofit>(named(AUTH_FREE_RETROFIT)).create(TokenService::class.java)
    } bind TokenService::class

    factory { SaveAppUserUseCase(get<AppUserRepository>()::saveAppUser) } bind SaveAppUserUseCase::class
}
