package io.snabble.phoneauth.core

import android.content.Context
import io.snabble.phoneauth.core.di.KoinProvider
import io.snabble.phoneauth.core.di.modules.authFreeModule
import io.snabble.phoneauth.core.di.modules.coreModule
import io.snabble.phoneauth.core.domain.AppUser
import io.snabble.phoneauth.core.feature.delete.di.phoneDeleteModule
import io.snabble.phoneauth.core.feature.login.di.phoneLoginModule
import io.snabble.phoneauth.core.feature.startauthflow.di.phoneAuthModule
import io.snabble.phoneauth.core.internal.appUser.di.appUserAndTokenModule
import io.snabble.phoneauth.core.internal.otp.di.otpModule
import io.snabble.phoneauth.core.internal.token.di.tokenModule
import io.snabble.phoneauth.network.auth.data.dto.AppUserDto
import kotlinx.coroutines.flow.Flow
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.android.ext.koin.androidContext
import org.koin.core.Koin
import org.koin.core.logger.Level
import org.koin.dsl.bind
import org.koin.dsl.koinApplication
import org.koin.dsl.module

/**
 * A configuration that is supplied to a new [SnabblePhoneAuth] instance.
 *
 * The properties must be set by the building function [io.snabble.phone.auth.sdk.SnabblePhoneAuth.getInstance].
 *
 */
class SnabblePhoneAuthConfiguration private constructor() {

    /**
     * Individual identifier for an app user
     *
     * Alternatively an [appUserFlow] can be provided
     *
     * @see [SnabblePhoneAuthAppCredentialsCallback]
     *
     */
    var userId: String? = null

    /**
     * Individual secret for the [userId]
     *
     * Alternatively an [appUserFlow] can be provided
     *
     * @see [SnabblePhoneAuthAppCredentialsCallback]
     *
     */
    var userSecret: String? = null

    /**
     * A flow of [AppUser]s can be provided to have the library automatically update to the latest app user.
     */
    var appUserFlow: Flow<AppUser?>? = null

    /**
     * @Required Individual secret of the current checked in project
     *
     */
    var projectId: String? = null

    /**
     * @Required Individual identifier of the current application
     *
     */
    var appId: String? = null

    /**
     * @Required Secret needed for authentication
     *
     */
    var appSecret: String? = null

    /**
     * The base url for Snabble PhoneAuth, the default url is the one for testing.
     *
     * Available Environments:
     * * production - _https://api.snabble.io_
     * * staging - _https://api.snabble-staging.io_
     * * testing - _https://api.snabble-testing.io_
     *
     */
    var baseUrl = "https://api.snabble-testing.io"

    /**
     * Callback for a new [userId] and [userSecret] if none has been provided.
     *
     * Each time a new instance of [SnabblePhoneAuth] is created without an appIdentifier and appSecret
     * new credentials are created and this callback gets called if the given phone number has been verified.
     *
     * **CAUTION:** Save the credentials provided through this callback to restore a user after the
     * [SnabblePhoneAuth] instance has been destroyed.
     *
     */
    var onNewAppCredentialsCallback: SnabblePhoneAuthAppCredentialsCallback? = null

    /**
     * Set log level for OkHttpClient used by [SnabblePhoneAuth].
     *
     * See [okhttp3.logging.HttpLoggingInterceptor.Level] for supported log levels.
     */
    var httpLogLevel: HttpLoggingInterceptor.Level = HttpLoggingInterceptor.Level.NONE

    internal lateinit var koin: Koin

    internal val appCredentials: AppUserDto?
        get() {
            val id = userId ?: return null
            val secret = userSecret ?: return null
            return AppUserDto(id = id, secret = secret)
        }

    private fun setupDi(context: Context) {
        val koinApplication = koinApplication {
            if (BuildConfig.DEBUG) printLogger(level = Level.DEBUG)
            androidContext(context.applicationContext)
            modules(
                authFreeModule,
                coreModule,
                phoneAuthModule,
                phoneLoginModule,
                phoneDeleteModule,
                appUserAndTokenModule,
                tokenModule,
                otpModule
            )
            modules(
                module {
                    single { this@SnabblePhoneAuthConfiguration } bind SnabblePhoneAuthConfiguration::class
                    single { httpLogLevel } bind HttpLoggingInterceptor.Level::class
                }
            )
        }
        koin = koinApplication.koin.also(KoinProvider::setKoin)
    }

    companion object {

        internal fun create(
            context: Context,
            init: SnabblePhoneAuthConfiguration.() -> Unit,
        ): SnabblePhoneAuthConfiguration = SnabblePhoneAuthConfiguration().apply {
            init()
            setupDi(context)
        }
    }
}
