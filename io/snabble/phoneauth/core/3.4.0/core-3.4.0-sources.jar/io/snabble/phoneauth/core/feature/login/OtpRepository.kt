package io.snabble.phoneauth.core.feature.login

import io.snabble.phoneauth.core.HTTP_STATUS_FORBIDDEN
import io.snabble.phoneauth.core.OperationFailedException
import io.snabble.phoneauth.core.Reason
import io.snabble.phoneauth.core.Result
import io.snabble.phoneauth.core.SnabblePhoneAuthConfiguration
import io.snabble.phoneauth.core.domain.AppUser
import io.snabble.phoneauth.core.domain.toAppUser
import io.snabble.phoneauth.core.feature.login.service.PhoneLogInService
import io.snabble.phoneauth.core.feature.login.service.dto.OtpCredentialsDto
import io.snabble.phoneauth.core.internal.appUser.AppUserRepository
import io.snabble.phoneauth.core.internal.token.TokenRepository
import io.snabble.phoneauth.core.toAuthError

internal sealed interface Intention

internal data object Login : Intention

internal data object ChangePhoneNumber : Intention

internal interface OtpRepository {
    suspend fun login(
        phoneNumber: String,
        otp: String,
    ): Result<Boolean>

    suspend fun changePhoneNumber(
        phoneNumber: String,
        otp: String,
    ): Result<Boolean>
}

internal class OtpRepositoryImpl(
    private val phoneLogInService: PhoneLogInService,
    private val appUserRepository: AppUserRepository,
    private val tokenRepository: TokenRepository,
    private val config: SnabblePhoneAuthConfiguration,
) : OtpRepository {
    override suspend fun login(
        phoneNumber: String,
        otp: String,
    ): Result<Boolean> = verifyOtp(phoneNumber = phoneNumber, otp = otp, intention = Login)

    override suspend fun changePhoneNumber(
        phoneNumber: String,
        otp: String,
    ): Result<Boolean> = verifyOtp(phoneNumber = phoneNumber, otp = otp, intention = ChangePhoneNumber)

    private suspend fun verifyOtp(
        phoneNumber: String,
        otp: String,
        intention: Intention,
    ): Result<Boolean> {
        val response =
            phoneLogInService.verify(
                otpCredentialsDto =
                    OtpCredentialsDto(
                        phoneNumber = phoneNumber,
                        otp = otp,
                        intention =
                            when (intention) {
                                ChangePhoneNumber -> "change-phone-number"
                                Login -> "sign-in"
                            }
                    )
            )

        return if (response.isSuccessful) {
            val appUserDto = response.body()
            val appUser = appUserDto?.toAppUser()
            if (appUser != null) {
                appUser.onNewAppUserCallback()
                appUserRepository.saveAppUser(appUserDto)
                tokenRepository.invalidateToken()
            }
            Result.success(true)
        } else {
            Result.failure(
                OperationFailedException("Could not verify phone number."),
                response.toAuthError(customMapping = { if (it == HTTP_STATUS_FORBIDDEN) Reason.DENIED else null })
            )
        }
    }

    private fun AppUser.onNewAppUserCallback() =
        config.onNewAppCredentialsCallback?.onNewAppUser(
            appId = id,
            appSecret = secret
        )
}
