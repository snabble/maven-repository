package io.snabble.phoneauth.core.feature.startauthflow

import io.snabble.phoneauth.core.OperationFailedException
import io.snabble.phoneauth.core.Result
import io.snabble.phoneauth.core.feature.delete.service.dto.PhoneNumber
import io.snabble.phoneauth.core.feature.startauthflow.service.PhoneAuthService
import io.snabble.phoneauth.core.toAuthError

interface StartAuthFlowUseCase {
    suspend operator fun invoke(phoneNumber: String): Result<Boolean>
}

internal class StartAuthFlowUseCaseImpl(
    private val service: PhoneAuthService,
) : StartAuthFlowUseCase {
    override suspend operator fun invoke(phoneNumber: String): Result<Boolean> {
        val response =
            service.startPhoneAuthorization(
                phoneNumber = PhoneNumber(phoneNumber)
            )

        return if (response.isSuccessful) {
            Result.success(true)
        } else {
            Result.failure(OperationFailedException("Auth flow failed."), response.toAuthError())
        }
    }
}
