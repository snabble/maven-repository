package io.snabble.phoneauth.core

import android.content.Context
import io.snabble.phoneauth.core.feature.changephonenumber.ChangePhoneNumberUseCase
import io.snabble.phoneauth.core.feature.delete.DeletePhoneNumberUseCase
import io.snabble.phoneauth.core.feature.login.PhoneLoginUseCase
import io.snabble.phoneauth.core.feature.startauthflow.StartAuthFlowUseCase

interface SnabblePhoneAuth {
    /**
     * Method call to start the auth flow. On Success the user receives an otp
     * for the login via sms.
     *
     * @param phoneNumber Number to be registered and receiver of the otp
     *
     * @return If the call has been a success a [Result.success] is returned. Otherwise a [Result.failure] containing
     * the http-exception will be returned.
     */
    suspend fun startAuthorization(phoneNumber: String): Result<Boolean>

    /**
     * Method call to start login if the given phone number.
     *
     * @param phoneNumber Number to be registered and receiver of the otp
     * @param otp One-time-password required for the login
     *
     * @return If the call has been a success a [Result.success] is returned. Otherwise a [Result.failure] containing
     * the http-exception will be returned.
     */
    suspend fun login(
        phoneNumber: String,
        otp: String,
    ): Result<Boolean>

    /**
     * Method call to change the phone number for an existing account.
     *
     * @param phoneNumber Number to be changed to and receiver of the otp
     * @param otp One-time-password required for the number change
     *
     * @return If the call has been a success a [Result.success] is returned. Otherwise a [Result.failure] containing
     * the http-exception will be returned.
     */
    suspend fun changePhoneNumber(
        phoneNumber: String,
        otp: String,
    ): Result<Boolean>

    /**
     * Method called to delete the stored number. On Success the number and the linked userId is deleted.
     * **CAUTION:** Once the number and the associated userId is delete it is no longer possible to restore the old
     * user. Thus the complete user history is no longer available.
     *
     * @return If the call has been a success a [Result.success] is returned. Otherwise a [Result.failure] containing
     * the http-exception will be returned.
     */
    suspend fun delete(): Result<Boolean>

    companion object {
        /**
         * Builder function to create an instance of [SnabblePhoneAuth].
         *
         * Here is a sample of how to use this function:
         *
         * ```
         * val phoneAuth: SnabblePhoneAuth = SnabblePhoneAuth.getInstance(context = context) {
         *     baseUrl = https://api.snabble-staging.io
         *     projectId = "demo-project-123"
         *     appId = "demo-app-123"
         *     appSecret = "BAGEKFSN$323FDFJ..."
         *
         *     onNewAppCredentialsCallback =
         *         SnabblePhoneAuthAppCredentialsCallback { id: String, secret: String ->
         *             sharedPreferences.saveAppCredentials(id, secret)
         *         }
         *
         *     val (id, secret) = sharedPreferences.getAppCredentials() ?: return@snabblePhoneAuth
         *
         *     appIdentifier = id
         *     appSecret = secret
         * }
         * ```
         *
         * @param context An Android [android.content.Context]
         * @param init The init block to create a [SnabblePhoneAuthConfiguration] for [SnabblePhoneAuth]
         *
         * @return An instance of [SnabblePhoneAuth] using the configuration from the [init] block
         *
         */
        fun getInstance(
            context: Context,
            init: SnabblePhoneAuthConfiguration.() -> Unit = {},
        ): SnabblePhoneAuth =
            with(SnabblePhoneAuthConfiguration.create(context, init).koin) {
                SnabblePhoneAuthImpl(
                    authorize = get(),
                    loginWithNumber = get(),
                    changeNumber = get(),
                    deleteNumber = get(),
                    appUserUpdateObserver = get()
                )
            }
    }
}

class SnabblePhoneAuthImpl internal constructor(
    private val authorize: StartAuthFlowUseCase,
    private val loginWithNumber: PhoneLoginUseCase,
    private val changeNumber: ChangePhoneNumberUseCase,
    private val deleteNumber: DeletePhoneNumberUseCase,
    appUserUpdateObserver: AppUserUpdateObserver,
) : SnabblePhoneAuth {
    init {
        appUserUpdateObserver.start()
    }

    override suspend fun startAuthorization(phoneNumber: String): Result<Boolean> = authorize(phoneNumber)

    override suspend fun login(
        phoneNumber: String,
        otp: String,
    ): Result<Boolean> = loginWithNumber(phoneNumber, otp)

    override suspend fun changePhoneNumber(
        phoneNumber: String,
        otp: String,
    ): Result<Boolean> = changeNumber(phoneNumber, otp)

    override suspend fun delete(): Result<Boolean> = deleteNumber()
}
