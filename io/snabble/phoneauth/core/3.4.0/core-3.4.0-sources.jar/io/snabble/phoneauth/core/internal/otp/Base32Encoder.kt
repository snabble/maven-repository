package io.snabble.phoneauth.core.internal.otp

object Base32Encoder {
    // 32 alpha-numeric characters.
    private const val ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
    private var chars: CharArray = ALPHABET.toCharArray()
    private var mask = 0
    private var shift = 0
    private var charMap: HashMap<Char, Int>

    init {
        mask = chars.size - 1
        shift = Integer.numberOfTrailingZeros(chars.size)
        charMap = HashMap()
        for (i in chars.indices) {
            charMap[chars[i]] = i
        }
    }

    @Throws(DecodingException::class)
    fun decode(encoded: String?): ByteArray? {
        encoded ?: return null
        return decodeInternal(encoded)
    }

    @Throws(DecodingException::class)
    private fun decodeInternal(encoded: String): ByteArray {
        // Remove whitespace and separators
        var finalencoded = encoded
        finalencoded =
            finalencoded
                .trim { it <= ' ' }
                .replace("-", "")
                .replace(" ", "")

        // Remove padding. Note: the padding is used as hint to determine how many
        // bits to decode from the last incomplete chunk (which is commented out
        // below, so this may have been wrong to start with).
        finalencoded = finalencoded.replaceFirst("=*$".toRegex(), "")

        // Canonicalize to all upper case
        finalencoded = finalencoded.uppercase()
        if (finalencoded.isEmpty()) {
            return ByteArray(0)
        }
        val outLength = finalencoded.length * shift / 8
        val result = ByteArray(outLength)
        var buffer = 0
        var next = 0
        var bitsLeft = 0
        for (c in finalencoded.toCharArray()) {
            if (!charMap.containsKey(c)) {
                throw DecodingException("Illegal character: $c")
            }
            buffer = buffer shl shift
            buffer = buffer or (charMap[c]!! and mask)
            bitsLeft += shift
            if (bitsLeft >= 8) {
                result[next++] = (buffer shr bitsLeft - 8).toByte()
                bitsLeft -= 8
            }
        }
        return result
    }

    class DecodingException(
        message: String?,
    ) : Exception(message)
}
