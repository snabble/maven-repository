package io.snabble.phoneauth.core.feature.delete.di

import io.snabble.phoneauth.core.feature.delete.DeletePhoneNumberUseCase
import io.snabble.phoneauth.core.feature.delete.DeletePhoneNumberUseCaseImpl
import io.snabble.phoneauth.core.feature.delete.service.PhoneDeleteService
import org.koin.core.module.dsl.factoryOf
import org.koin.dsl.bind
import org.koin.dsl.module
import retrofit2.Retrofit

internal val phoneDeleteModule =
    module {
        factoryOf(::DeletePhoneNumberUseCaseImpl) bind DeletePhoneNumberUseCase::class
        single {
            get<Retrofit>().create(PhoneDeleteService::class.java)
        } bind PhoneDeleteService::class
    }
