package io.snabble.phoneauth.core

class MissingArgumentException(
    override val message: String,
) : RuntimeException()

class OperationFailedException(
    override val message: String,
) : RuntimeException()
