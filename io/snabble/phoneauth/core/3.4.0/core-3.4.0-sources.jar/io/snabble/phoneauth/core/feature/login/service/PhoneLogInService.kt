package io.snabble.phoneauth.core.feature.login.service

import io.snabble.phoneauth.core.feature.login.service.dto.OtpCredentialsDto
import io.snabble.phoneauth.network.auth.data.dto.AppUserDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

internal interface PhoneLogInService {
    /**
     * [API Doc](https://docs.snabble.io/tokens/#tag/Phone-number-verification/operation/submitPhoneNumberVerificationOTP)
     */
    @POST("/apps/users/me/verification/phone-number/otp")
    suspend fun verify(
        @Body otpCredentialsDto: OtpCredentialsDto,
    ): Response<AppUserDto?>
}
