package io.snabble.phoneauth.core.internal.appUser

import io.snabble.phoneauth.network.auth.data.dto.AppUserDto

internal fun interface SaveAppUserUseCase : suspend (AppUserDto?) -> Unit
