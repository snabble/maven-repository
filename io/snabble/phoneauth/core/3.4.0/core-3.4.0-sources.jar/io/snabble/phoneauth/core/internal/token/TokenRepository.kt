package io.snabble.phoneauth.core.internal.token

import io.snabble.phoneauth.core.internal.appUser.AppUserAndTokenRepository
import io.snabble.phoneauth.core.internal.appUser.AppUserRepository
import io.snabble.phoneauth.network.auth.data.dto.TokenDto

internal interface TokenRepository {
    fun saveToken(tokenDto: TokenDto): Boolean

    suspend fun getToken(): TokenDto?

    suspend fun fetchNewToken(): TokenDto?

    suspend fun validateToken(token: TokenDto): Boolean

    fun invalidateToken()
}

internal class TokenRepositoryImpl(
    private val appUserAndTokenRepository: AppUserAndTokenRepository,
    private val appUserRepository: AppUserRepository,
) : TokenRepository {
    private var tokenDto: TokenDto? = null

    override fun saveToken(tokenDto: TokenDto): Boolean {
        this.tokenDto = tokenDto
        return true
    }

    override suspend fun getToken(): TokenDto? = tokenDto

    override suspend fun fetchNewToken(): TokenDto? {
        val appUser = appUserRepository.getAppUser()
        return if (appUser == null) {
            appUserAndTokenRepository
                .getAppUserAndToken(false)
                ?.also {
                    appUserRepository.saveAppUser(it.appUserDto)
                }?.tokenDto
                ?.also {
                    saveToken(it)
                }
        } else {
            appUserAndTokenRepository.getToken(false)?.also {
                saveToken(it)
            }
        }
    }

    override suspend fun validateToken(token: TokenDto): Boolean = appUserAndTokenRepository.validateToken(token)

    override fun invalidateToken() {
        tokenDto = null
        appUserAndTokenRepository.invalidateTimeOffset()
    }
}
