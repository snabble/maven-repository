package io.snabble.phoneauth.core.feature.changephonenumber

import io.snabble.phoneauth.core.Result

internal fun interface ChangePhoneNumberUseCase {
    suspend operator fun invoke(
        phoneNumber: String,
        otp: String,
    ): Result<Boolean>
}
