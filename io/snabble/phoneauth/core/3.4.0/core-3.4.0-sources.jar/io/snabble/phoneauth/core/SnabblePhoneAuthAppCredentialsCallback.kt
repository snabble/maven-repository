package io.snabble.phoneauth.core

/**
 * Callback for a new app user. This callback is only called if no
 * [SnabblePhoneAuthConfiguration.userId] and no [SnabblePhoneAuthConfiguration.userSecret] has been
 * provided.
 *
 * To make use of this callback set it in the builder functions
 * [io.snabble.phone.auth.sdk.SnabblePhoneAuth.getInstance] init block.
 *
 * **CAUTION:** Save the credentials provided through this callback to restore an app/user after the
 * [SnabblePhoneAuth] instance has been destroyed.
 *
 */
fun interface SnabblePhoneAuthAppCredentialsCallback {
    /**
     * @param appId A new app identifier for the current app instance.
     * @param appSecret The secret for the new appId.
     */
    fun onNewAppUser(
        appId: String,
        appSecret: String,
    )
}
