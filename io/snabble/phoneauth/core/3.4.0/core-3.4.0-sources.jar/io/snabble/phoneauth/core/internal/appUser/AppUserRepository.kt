package io.snabble.phoneauth.core.internal.appUser

import io.snabble.phoneauth.core.SnabblePhoneAuthConfiguration
import io.snabble.phoneauth.network.auth.data.dto.AppUserDto

interface AppUserRepository {
    suspend fun saveAppUser(appUserDto: AppUserDto?)

    suspend fun getAppUser(): AppUserDto?
}

internal class AppUserRepositoryImpl(
    config: SnabblePhoneAuthConfiguration,
) : AppUserRepository {
    private var appUser: AppUserDto? = config.appCredentials

    override suspend fun getAppUser(): AppUserDto? = appUser

    override suspend fun saveAppUser(appUserDto: AppUserDto?) {
        appUser = appUserDto
    }
}
