package io.snabble.phoneauth.core

/**
 * Represents the snabble phone auth error.
 *
 * @property reason Reason for the error
 * @property exception Actual Exception returned by the snabble API. Typically a [HTTPException] with the response
 * object that contains an error body that contains a [structured error](https://docs.snabble.io/docs/api/api_general/#structured-errors).
 *
 * @since 1.0.1
 */
data class AuthError(
    val reason: Reason,
    val exception: Throwable? = null,
)

/**
 * Represents an Error occurring on the pay server.
 */
enum class Reason {
    /**
     * Library error, typically not fixable. Please reach out to the support.
     *
     * @since 1.0.1
     */
    LIBRARY_ERROR,

    /**
     * Missing or wrong configuration parameter
     *
     * @since 1.0.1
     */
    CONFIGURATION_ERROR,

    /**
     * Invalid or missing credentials, or wrong OTP.
     *
     * @since 1.0.1
     */
    DENIED,

    /**
     * Invalid or missing credentials.
     *
     * @since 1.0.1
     */
    FORBIDDEN,

    /**
     * Limit per phone number exceeded. Please look into the error exception for more details.
     *
     * Wait at least one minute before trying again. There is a pool of 5 attempts initially available. Each SMS sent
     * spends one of these. The pool will be refilled at a rate of about one attempt per minute.
     *
     * @since 1.0.1
     */
    LIMIT_EXCEEDED,

    /**
     * Unknown error. More information might be in the error exception. Typically not fixable.
     *
     * @since 1.0.1
     */
    UNKNOWN,

    /**
     * Validation failed, typically data is out-of-range. Please look into the error exception for more details.
     *
     * @since 1.0.1
     */
    VALIDATION_FAILED,
}
