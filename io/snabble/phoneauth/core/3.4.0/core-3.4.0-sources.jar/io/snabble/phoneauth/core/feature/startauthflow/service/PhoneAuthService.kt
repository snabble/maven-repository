package io.snabble.phoneauth.core.feature.startauthflow.service

import io.snabble.phoneauth.core.feature.delete.service.dto.PhoneNumber
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

internal interface PhoneAuthService {
    /**
     * [API Doc](https://docs.snabble.io/tokens/#tag/Phone-number-verification/operation/startPhoneNumberVerification)
     */
    @POST("/apps/users/me/verification/phone-number")
    suspend fun startPhoneAuthorization(
        @Body phoneNumber: PhoneNumber,
    ): Response<Void>
}
