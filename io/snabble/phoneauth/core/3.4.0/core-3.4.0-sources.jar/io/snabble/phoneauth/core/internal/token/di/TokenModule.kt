package io.snabble.phoneauth.core.internal.token.di

import io.snabble.phoneauth.core.internal.token.GetTokenUseCaseImpl
import io.snabble.phoneauth.core.internal.token.TokenRepository
import io.snabble.phoneauth.core.internal.token.TokenRepositoryImpl
import io.snabble.phoneauth.network.auth.domain.interceptor.GetTokenUseCase
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.bind
import org.koin.dsl.module

internal val tokenModule =
    module {
        singleOf(::TokenRepositoryImpl) bind TokenRepository::class
        singleOf(::GetTokenUseCaseImpl) bind GetTokenUseCase::class
    }
