package io.snabble.phoneauth.core

import io.snabble.phoneauth.core.internal.appUser.AppUserRepository
import io.snabble.phoneauth.core.internal.token.TokenRepository
import io.snabble.phoneauth.network.auth.data.dto.AppUserDto
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

internal fun interface AppUserUpdateObserver {
    fun start()
}

internal class AppUserUpdateObserverImpl(
    private val config: SnabblePhoneAuthConfiguration,
    private val appUserRepository: AppUserRepository,
    private val tokenRepository: TokenRepository,
    private val coroutineScope: CoroutineScope,
) : AppUserUpdateObserver {
    override fun start() {
        config.appUserFlow
            ?.onEach { user ->
                if (appUserRepository.getAppUser()?.id != user?.id) {
                    appUserRepository.saveAppUser(user?.let { AppUserDto(user.id, user.secret) })
                    tokenRepository.invalidateToken()
                }
            }?.launchIn(coroutineScope)
    }
}
