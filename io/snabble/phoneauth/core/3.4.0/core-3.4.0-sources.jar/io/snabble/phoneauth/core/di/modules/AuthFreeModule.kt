package io.snabble.phoneauth.core.di.modules

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.core.qualifier.named
import org.koin.dsl.bind
import org.koin.dsl.module
import retrofit2.Retrofit

internal val authFreeModule =
    module {

        single(named(AUTH_FREE_RETROFIT)) {
            Retrofit
                .Builder()
                .client(get(named(AUTH_FREE_OK_HTTP_CLIENT)))
                .addConverterFactory(get(named(RETROFIT_JSON_CONVERTER_FACTORY)))
                .baseUrl(get<String>(named(SNABBLE_PHONE_AUTH_URL)))
                .build()
        } bind Retrofit::class

        single(named(AUTH_FREE_OK_HTTP_CLIENT)) {
            OkHttpClient
                .Builder()
                .addInterceptor(get<HttpLoggingInterceptor>(named(OKHTTP_LOGGING_INTERCEPTOR)))
                .build()
        } bind OkHttpClient::class
    }

internal const val AUTH_FREE_OK_HTTP_CLIENT = "Auth-Free-OkHttpClient"
internal const val AUTH_FREE_RETROFIT = "Auth-Free-Retrofit"
