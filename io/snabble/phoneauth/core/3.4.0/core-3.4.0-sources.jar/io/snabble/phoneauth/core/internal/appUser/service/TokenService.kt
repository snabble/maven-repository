package io.snabble.phoneauth.core.internal.appUser.service

import io.snabble.phoneauth.network.auth.data.dto.TokenDto
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

internal interface TokenService {
    @GET("/tokens")
    suspend fun fetchToken(
        @Header("Authorization") header: String,
        @Query("project") projectId: String,
        @Query("role") role: String = "retailerApp",
    ): Response<TokenDto>
}
