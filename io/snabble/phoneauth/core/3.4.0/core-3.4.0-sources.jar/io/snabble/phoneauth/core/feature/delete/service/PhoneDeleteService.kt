package io.snabble.phoneauth.core.feature.delete.service

import retrofit2.Response
import retrofit2.http.HTTP

internal interface PhoneDeleteService {
    /**
     * [API Doc](https://docs.snabble.io/tokens/#tag/App-user-data/operation/deletePhoneNumber)
     */
    @HTTP(method = "DELETE", path = "/apps/users/me/phone-number")
    suspend fun delete(): Response<Void>
}
