package io.snabble.phoneauth.core.domain

import io.snabble.phoneauth.network.auth.data.dto.AppUserDto

/**
 * Represents an already existing app user.
 * If an app user is already mapped to a phone number it will be returned after receiving the otp
 *
 * @property id A app identifier of the app instance mapped to the phone number.
 * @property secret The secret for the appId.
 */
data class AppUser(
    val id: String,
    val secret: String,
)

internal fun AppUserDto.toAppUser(): AppUser? {
    val id = id ?: return null
    val secret = secret ?: return null
    return AppUser(
        id = id,
        secret = secret
    )
}
