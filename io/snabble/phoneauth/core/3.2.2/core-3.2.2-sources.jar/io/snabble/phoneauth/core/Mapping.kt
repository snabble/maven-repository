package io.snabble.phoneauth.core

import retrofit2.HttpException
import retrofit2.Response

internal fun <T> Response<T>.toAuthError(
    customMapping: ((code: Int) -> Reason?)? = null,
): AuthError = when (code()) {
    HTTP_STATUS_BAD_REQUEST -> AuthError(
        reason = Reason.LIBRARY_ERROR,
        exception = HttpException(this)
    )

    HTTP_STATUS_FORBIDDEN -> AuthError(
        reason = customMapping?.invoke(HTTP_STATUS_FORBIDDEN) ?: Reason.FORBIDDEN,
        exception = HttpException(this)
    )

    HTTP_STATUS_UNPROCESSABLE_CONTENT -> AuthError(
        reason = Reason.VALIDATION_FAILED,
        exception = HttpException(this)
    )

    HTTP_STATUS_TOO_MANY_REQUESTS -> AuthError(
        reason = Reason.LIMIT_EXCEEDED,
        exception = HttpException(this)
    )

    else -> AuthError(
        reason = Reason.UNKNOWN,
        exception = HttpException(this)
    )
}

internal const val HTTP_STATUS_BAD_REQUEST = 400
internal const val HTTP_STATUS_FORBIDDEN = 403
internal const val HTTP_STATUS_TOO_MANY_REQUESTS = 429
internal const val HTTP_STATUS_UNPROCESSABLE_CONTENT = 422
