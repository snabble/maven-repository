package io.snabble.phoneauth.core.feature.startauthflow.di

import io.snabble.phoneauth.core.feature.startauthflow.StartAuthFlowUseCase
import io.snabble.phoneauth.core.feature.startauthflow.StartAuthFlowUseCaseImpl
import io.snabble.phoneauth.core.feature.startauthflow.service.PhoneAuthService
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.bind
import org.koin.dsl.module
import retrofit2.Retrofit

internal val phoneAuthModule = module {

    singleOf(::StartAuthFlowUseCaseImpl) bind StartAuthFlowUseCase::class
    single {
        get<Retrofit>().create(PhoneAuthService::class.java)
    } bind PhoneAuthService::class
}
