package io.snabble.phoneauth.core.feature.startauthflow.service.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class AuthCredentialsDto(
    @SerialName("userID") val userID: String,
    @SerialName("phoneNumber") val phoneNumber: String,
)
