package io.snabble.phoneauth.core.feature.delete.service.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class PhoneNumber(
    @SerialName("phoneNumber") val phoneNumber: String,
)
