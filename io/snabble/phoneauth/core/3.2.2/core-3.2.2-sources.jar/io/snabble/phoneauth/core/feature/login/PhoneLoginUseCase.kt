package io.snabble.phoneauth.core.feature.login

import io.snabble.phoneauth.core.Result

internal fun interface PhoneLoginUseCase {

    suspend operator fun invoke(phoneNumber: String, otp: String): Result<Boolean>
}
