package io.snabble.phoneauth.core.internal.appUser.service

import io.snabble.phoneauth.network.auth.data.dto.AppUserAndTokenDto
import retrofit2.Response
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

internal interface AppUserAndTokenService {

    @POST("/apps/{appId}/users")
    suspend fun fetchAppUserAndToken(
        @Header("Authorization") header: String,
        @Path("appId") appId: String,
        @Query("project") projectId: String,
    ): Response<AppUserAndTokenDto>
}
