package io.snabble.phoneauth.core.feature.login.di

import io.snabble.phoneauth.core.feature.changephonenumber.ChangePhoneNumberUseCase
import io.snabble.phoneauth.core.feature.login.OtpRepository
import io.snabble.phoneauth.core.feature.login.OtpRepositoryImpl
import io.snabble.phoneauth.core.feature.login.PhoneLoginUseCase
import io.snabble.phoneauth.core.feature.login.service.PhoneLogInService
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.bind
import org.koin.dsl.module
import retrofit2.Retrofit

internal val phoneLoginModule = module {

    singleOf(::OtpRepositoryImpl) bind OtpRepository::class
    single { get<Retrofit>().create(PhoneLogInService::class.java) } bind PhoneLogInService::class
    single { PhoneLoginUseCase(get<OtpRepository>()::login) } bind PhoneLoginUseCase::class
    single { ChangePhoneNumberUseCase(get<OtpRepository>()::changePhoneNumber) } bind ChangePhoneNumberUseCase::class
}
