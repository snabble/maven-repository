package io.snabble.phoneauth.core.di.modules

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import io.snabble.phoneauth.core.SnabblePhoneAuthConfiguration
import io.snabble.phoneauth.network.auth.domain.interceptor.PhoneAuthInterceptor
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import org.koin.core.qualifier.named
import org.koin.dsl.bind
import org.koin.dsl.module
import retrofit2.Converter
import retrofit2.Retrofit

internal val coreModule = module {
    single(named(SNABBLE_PHONE_AUTH_URL)) { get<SnabblePhoneAuthConfiguration>().baseUrl } bind String::class

    single {
        Retrofit.Builder()
            .client(get())
            .addConverterFactory(get(named(RETROFIT_JSON_CONVERTER_FACTORY)))
            .baseUrl(get<String>(named(SNABBLE_PHONE_AUTH_URL)))
            .build()
    } bind Retrofit::class

    single {
        OkHttpClient.Builder()
            .addInterceptor(PhoneAuthInterceptor(getAccessToken = get()))
            .build()
    } bind OkHttpClient::class

    factory(named(RETROFIT_JSON_CONVERTER_FACTORY)) {
        @OptIn(ExperimentalSerializationApi::class)
        get<Json>().asConverterFactory("application/json".toMediaType())
    } bind Converter.Factory::class

    factory { Json { ignoreUnknownKeys = true; isLenient = true } } bind Json::class
}

internal const val RETROFIT_JSON_CONVERTER_FACTORY = "Retrofit-Json-Converter-Factory"
internal const val SNABBLE_PHONE_AUTH_URL = "Snabble-Phone-Auth-Url"
