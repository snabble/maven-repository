package io.snabble.phoneauth.core.internal.otp

object Base32Encoder {

    // 32 alpha-numeric characters.
    private const val ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
    private var DIGITS: CharArray = ALPHABET.toCharArray()
    private var MASK = 0
    private var SHIFT = 0
    private var CHAR_MAP: HashMap<Char, Int>

    init {
        MASK = DIGITS.size - 1
        SHIFT = Integer.numberOfTrailingZeros(DIGITS.size)
        CHAR_MAP = HashMap()
        for (i in DIGITS.indices) {
            CHAR_MAP[DIGITS[i]] = i
        }
    }

    @Throws(DecodingException::class)
    fun decode(encoded: String?): ByteArray? {
        encoded ?: return null
        return decodeInternal(encoded)
    }

    @Throws(DecodingException::class)
    private fun decodeInternal(encoded: String): ByteArray {
        // Remove whitespace and separators
        var finalencoded = encoded
        finalencoded =
            finalencoded.trim { it <= ' ' }
                .replace("-", "")
                .replace(" ", "")

        // Remove padding. Note: the padding is used as hint to determine how many
        // bits to decode from the last incomplete chunk (which is commented out
        // below, so this may have been wrong to start with).
        finalencoded = finalencoded.replaceFirst("=*$".toRegex(), "")

        // Canonicalize to all upper case
        finalencoded = finalencoded.uppercase()
        if (finalencoded.isEmpty()) {
            return ByteArray(0)
        }
        val outLength = finalencoded.length * SHIFT / 8
        val result = ByteArray(outLength)
        var buffer = 0
        var next = 0
        var bitsLeft = 0
        for (c in finalencoded.toCharArray()) {
            if (!CHAR_MAP.containsKey(c)) {
                throw DecodingException("Illegal character: $c")
            }
            buffer = buffer shl SHIFT
            buffer = buffer or (CHAR_MAP[c]!! and MASK)
            bitsLeft += SHIFT
            if (bitsLeft >= 8) {
                result[next++] = (buffer shr bitsLeft - 8).toByte()
                bitsLeft -= 8
            }
        }
        return result
    }

    class DecodingException(message: String?) : Exception(message)
}
