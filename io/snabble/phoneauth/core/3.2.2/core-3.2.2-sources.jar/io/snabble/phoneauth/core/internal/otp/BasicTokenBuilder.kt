package io.snabble.phoneauth.core.internal.otp

import android.util.Base64
import android.util.Log
import io.snabble.phoneauth.core.SnabblePhoneAuthConfiguration
import io.snabble.phoneauth.core.internal.appUser.AppUserRepository
import java.io.UnsupportedEncodingException

internal interface BasicTokenBuilder {

    suspend fun basicToken(time: Long): String?

    suspend fun basicAppUserAndToken(time: Long): String?
}

internal class BasicTokenBuilderImpl(
    private val config: SnabblePhoneAuthConfiguration,
    private val appUserRepository: AppUserRepository,
) : BasicTokenBuilder {

    override suspend fun basicToken(time: Long): String? {
        val appUser = appUserRepository.getAppUser() ?: return null
        val appId = config.appId ?: return null
        val tOtp = generateTimeOtp(time) ?: return null

        val authString = "$appId:$tOtp:${appUser.id}:${appUser.secret}"

        return encodeBase64(authString)
    }

    override suspend fun basicAppUserAndToken(time: Long): String? {
        val appId = config.appId ?: return null
        val tOtp = generateTimeOtp(time) ?: return null

        val authString = "$appId:$tOtp"

        return encodeBase64(authString)
    }

    private fun generateTimeOtp(time: Long): String? {
        val secret = config.appSecret ?: return null
        return try {
            val secretData = Base32Encoder.decode(secret) ?: return null
            val timeOtp = Totp(H_MAC_SHA_256, secretData, LENGTH, TIME_STEPS)
            timeOtp.generate(time)
        } catch (e: Base32Encoder.DecodingException) {
            Log.e("xx", "encodeBase64: ", e)
            null
        }
    }

    private fun encodeBase64(string: String): String? {
        return try {
            val base64 =
                Base64.encodeToString(
                    string.trim().toByteArray(charset("UTF-8")),
                    Base64.NO_WRAP
                )
            "Basic $base64"
        } catch (e: UnsupportedEncodingException) {
            Log.e("xx", "encodeBase64: ", e)
            null
        }
    }

    companion object {

        private const val H_MAC_SHA_256 = "HmacSHA256"
        private const val TIME_STEPS = 30
        private const val LENGTH = 8
    }
}
