package io.snabble.phoneauth.core.internal.otp.di

import io.snabble.phoneauth.core.internal.otp.BasicTokenBuilder
import io.snabble.phoneauth.core.internal.otp.BasicTokenBuilderImpl
import org.koin.core.module.dsl.factoryOf
import org.koin.dsl.bind
import org.koin.dsl.module

internal val otpModule = module {
    factoryOf(::BasicTokenBuilderImpl) bind BasicTokenBuilder::class
}
