package io.snabble.phoneauth.core.feature.delete

import io.snabble.phoneauth.core.OperationFailedException
import io.snabble.phoneauth.core.Result
import io.snabble.phoneauth.core.feature.delete.service.PhoneDeleteService
import io.snabble.phoneauth.core.toAuthError
import retrofit2.Retrofit

internal interface DeletePhoneNumberUseCase {

    suspend operator fun invoke(): Result<Boolean>
}

internal class DeletePhoneNumberUseCaseImpl(
    private val retrofit: Retrofit,
) : DeletePhoneNumberUseCase {

    override suspend operator fun invoke(): Result<Boolean> {
        val deleteService = retrofit.create(PhoneDeleteService::class.java)
        val response = deleteService.delete()
        return if (response.isSuccessful) {
            Result.success(true)
        } else {
            Result.failure(OperationFailedException("Could not delete phone number."), response.toAuthError())
        }
    }
}
