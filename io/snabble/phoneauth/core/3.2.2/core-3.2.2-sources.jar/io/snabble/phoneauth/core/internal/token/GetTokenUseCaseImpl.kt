package io.snabble.phoneauth.core.internal.token

import io.snabble.phoneauth.network.auth.data.dto.TokenDto
import io.snabble.phoneauth.network.auth.domain.interceptor.GetTokenUseCase

internal class GetTokenUseCaseImpl(
    private val tokenRepository: TokenRepository,
) : GetTokenUseCase {

    override suspend fun invoke(): TokenDto? {
        val token = tokenRepository.getToken()
        return if (token.isInValid()) {
            tokenRepository.fetchNewToken()
        } else {
            token
        }
    }

    private suspend fun TokenDto?.isInValid(): Boolean {
        this ?: return true
        return tokenRepository.validateToken(this)
    }
}
