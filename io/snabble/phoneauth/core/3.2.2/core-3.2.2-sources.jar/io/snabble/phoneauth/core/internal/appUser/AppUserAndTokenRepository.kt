package io.snabble.phoneauth.core.internal.appUser

import io.snabble.phoneauth.core.SnabblePhoneAuthConfiguration
import io.snabble.phoneauth.core.internal.appUser.service.AppUserAndTokenService
import io.snabble.phoneauth.core.internal.appUser.service.TokenService
import io.snabble.phoneauth.core.internal.otp.BasicTokenBuilder
import io.snabble.phoneauth.network.auth.data.dto.AppUserAndTokenDto
import io.snabble.phoneauth.network.auth.data.dto.AppUserDto
import io.snabble.phoneauth.network.auth.data.dto.TokenDto
import okhttp3.Response

internal interface AppUserAndTokenRepository {

    suspend fun getAppUserAndToken(isRetry: Boolean): AppUserAndTokenDto?

    suspend fun getToken(isRetry: Boolean): TokenDto?

    suspend fun validateToken(token: TokenDto): Boolean

    fun invalidateTimeOffset()
}

internal class AppUserAndTokenRepositoryImpl constructor(
    private val appUserAndTokenService: AppUserAndTokenService,
    private val tokenService: TokenService,
    private val config: SnabblePhoneAuthConfiguration,
    private val basicTokenBuilder: BasicTokenBuilder,
) : AppUserAndTokenRepository {

    // Time offset to calculate to validate token
    private var timeOffset: Long = 0

    override suspend fun getAppUserAndToken(isRetry: Boolean): AppUserAndTokenDto? {
        val appId = config.appId ?: return null
        val projectId = config.projectId ?: return null

        val timeOtp = basicTokenBuilder.basicAppUserAndToken(getOffsetTime()) ?: return null

        val response = appUserAndTokenService.fetchAppUserAndToken(timeOtp, appId, projectId)

        return if (!response.isSuccessful && !isRetry) {
            getAppUserAndToken(true)
        } else {
            adjustTimeOffset(response.raw())
            response.body()?.also {
                it.appUserDto.onNewAppUserCallback()
            }
        }
    }

    override suspend fun getToken(isRetry: Boolean): TokenDto? {
        val projectId = config.projectId ?: return null
        val timeOtp = basicTokenBuilder.basicToken(getOffsetTime()) ?: return null

        val response = tokenService.fetchToken(timeOtp, projectId)

        return if (!response.isSuccessful && !isRetry) {
            getToken(true)
        } else {
            adjustTimeOffset(response.raw())
            response.body()
        }
    }

    override suspend fun validateToken(token: TokenDto): Boolean {
        val tokenInterval = (token.expiresAt - token.issuedAt)
        val invalidAt = token.issuedAt + tokenInterval / 2
        return timeOffset >= invalidAt
    }

    override fun invalidateTimeOffset() {
        timeOffset = 0
    }

    private fun AppUserDto.onNewAppUserCallback() {
        val id = id ?: return
        val secret = secret ?: return
        config.onNewAppCredentialsCallback?.onNewAppUser(
            appId = id,
            appSecret = secret
        )
    }

    private fun getOffsetTime(): Long {
        return (System.currentTimeMillis() + timeOffset) / 1000
    }

    private fun adjustTimeOffset(response: Response) {
        val serverDate = response.headers.getDate("Date")
        if (serverDate != null) {
            timeOffset = serverDate.time - System.currentTimeMillis()
        }
    }
}
