package io.snabble.phoneauth.core.feature.login.service.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class OtpCredentialsDto(
    @SerialName("phoneNumber") val phoneNumber: String,
    @SerialName("otp") val otp: String,
    @SerialName("intention") val intention: String,
)
