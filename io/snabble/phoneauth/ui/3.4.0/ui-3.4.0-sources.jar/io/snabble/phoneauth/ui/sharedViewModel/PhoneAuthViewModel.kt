package io.snabble.phoneauth.ui.sharedViewModel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class PhoneAuthViewModel : ViewModel() {
    private val _state = MutableStateFlow<PhoneAuthState>(Idle)
    val state = _state.asStateFlow()

    private val _event = MutableStateFlow<PhoneAuthEvent>(Init)
    val event = _event.asStateFlow()

    fun sendEvent(event: PhoneAuthEvent) {
        _state.tryEmit(Loading)
        _event.value = event
    }

    fun onSuccess() {
        _state.tryEmit(Success)
    }

    fun onError(message: String) {
        _state.tryEmit(Error(message))
        _event.tryEmit(Init)
    }

    fun reset() {
        _state.tryEmit(Idle)
        _event.tryEmit(Init)
    }
}

sealed interface PhoneAuthEvent

object Init : PhoneAuthEvent

object Abort : PhoneAuthEvent

data class RequestOtp(
    val phoneNumber: String,
) : PhoneAuthEvent

data class RefreshOtp(
    val phoneNumber: String,
) : PhoneAuthEvent

data class SendOtp(
    val phoneNumber: String,
    val otp: String,
) : PhoneAuthEvent

sealed interface PhoneAuthState

object Idle : PhoneAuthState

object Loading : PhoneAuthState

object Success : PhoneAuthState

data class Error(
    val message: String,
) : PhoneAuthState
