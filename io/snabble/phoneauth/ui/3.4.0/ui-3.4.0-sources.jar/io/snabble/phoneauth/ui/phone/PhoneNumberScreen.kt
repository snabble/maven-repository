package io.snabble.phoneauth.ui.phone

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.togitech.ccp.component.TogiCountryCodePicker
import com.togitech.ccp.component.getFullPhoneNumber
import io.snabble.phoneauth.ui.R
import io.snabble.phoneauth.ui.theme.SnabblePhoneAuthTheme

@Composable
fun PhoneNumberScreen(
    modifier: Modifier = Modifier,
    onSendRequest: (String) -> Unit,
    showLoadingIndicator: Boolean = true,
    onCancel: () -> Unit,
) {
    val phoneNumber = rememberSaveable { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    SnabblePhoneAuthTheme {
        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .then(modifier),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(32.dp))
            Text(
                modifier =
                    modifier
                        .wrapContentSize()
                        .padding(horizontal = 48.dp),
                text = stringResource(id = R.string.Snabble_Phone_EnterNumber),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(32.dp))
            TogiCountryCodePicker(
                text = phoneNumber.value,
                onValueChange = {
                    phoneNumber.value = it
                },
                bottomStyle = false,
                showCountryFlag = true,
                showCountryCode = true,
                shape = RoundedCornerShape(4.dp),
                focusedBorderColor = MaterialTheme.colorScheme.primary
            )
            Button(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                onClick = {
                    onSendRequest(getFullPhoneNumber())
                    focusManager.clearFocus()
                }
            ) {
                Text(text = stringResource(id = R.string.Snabble_Phone_SendRequest))
                if (showLoadingIndicator) {
                    Spacer(modifier = Modifier.width(8.dp))
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            TextButton(onClick = { onCancel() }) {
                Text(text = stringResource(id = R.string.Snabble_Phone_Back))
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true
)
@Composable
fun PhoneNumberScreenPreview() {
    PhoneNumberScreen(
        onSendRequest = {},
        onCancel = {}
    )
}
