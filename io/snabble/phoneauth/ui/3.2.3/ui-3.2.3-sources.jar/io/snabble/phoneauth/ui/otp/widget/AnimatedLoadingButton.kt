package io.snabble.phoneauth.ui.otp.widget

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AnimatedLoadingButton(
    text: String,
    refreshRate: Int,
    onclick: () -> Unit,
) {
    val ticks = remember { mutableIntStateOf(refreshRate) }
    val buttonTextColor = remember {
        mutableStateOf(Color.LightGray)
    }
    val startAnimation = remember {
        mutableStateOf(false)
    }

    val coroutineScope = rememberCoroutineScope()

    val getLocationOnClick: () -> Unit = {
        ticks.intValue = refreshRate
        coroutineScope.launch {
            while (ticks.intValue > 0) {
                delay(1000)
                ticks.intValue -= 1000
                if (ticks.intValue == refreshRate - 1000) {
                    startAnimation.value = true
                }
                if (ticks.intValue == 0) {
                    buttonTextColor.value = Color.White
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        getLocationOnClick()
    }

    Box(modifier = Modifier.fillMaxWidth()) {
        AnimatedContent(
            targetState = startAnimation.value,
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(32.dp)),
            contentAlignment = Alignment.Center,
            content = { animate ->
                if (animate) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .background(color = MaterialTheme.colorScheme.primary)
                            .clickable(enabled = ticks.intValue == 0) {
                                onclick()
                                startAnimation.value = false
                                ticks.intValue = refreshRate
                                buttonTextColor.value = Color.LightGray
                                getLocationOnClick()
                            }
                    )
                }
            },
            transitionSpec = {
                slideInHorizontally(
                    animationSpec = tween(refreshRate - 1000),
                    initialOffsetX = { -it }
                ) togetherWith ExitTransition.None
            },
            label = "ProgressAnimation"
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(
                    border = BorderStroke(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.primary
                    ),
                    shape = RoundedCornerShape(32.dp)
                )
                .height(40.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                color = buttonTextColor.value,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}
