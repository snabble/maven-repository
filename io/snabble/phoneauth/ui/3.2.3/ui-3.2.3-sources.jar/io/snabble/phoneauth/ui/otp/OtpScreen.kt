package io.snabble.phoneauth.ui.otp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.autofill.AutofillNode
import androidx.compose.ui.autofill.AutofillType
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.onFocusEvent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalAutofill
import androidx.compose.ui.platform.LocalAutofillTree
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import io.snabble.phoneauth.ui.R
import io.snabble.phoneauth.ui.otp.widget.AnimatedLoadingButton

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun OtpScreen(
    modifier: Modifier = Modifier,
    refreshRate: Int = 30000,
    phoneNumber: String,
    isError: Boolean = false,
    showLoadingIndicator: Boolean = true,
    errorMessage: String = "",
    onAction: (String) -> Unit,
    onNewRequest: () -> Unit,
    onCancel: () -> Unit,
) {
    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val focusedDivider = remember {
        mutableStateOf(false)
    }
    val borderColor: Color =
        if (!focusedDivider.value && isError) {
            Color.Red
        } else if (!focusedDivider.value) {
            Color.Black
        } else {
            MaterialTheme.colorScheme.primary
        }

    val otp = remember {
        mutableStateOf("")
    }

    val autofillNode = AutofillNode(
        autofillTypes = listOf(AutofillType.SmsOtpCode),
        onFill = { otp.value = it }
    )
    val autofill = LocalAutofill.current

    LocalAutofillTree.current += autofillNode
    Column(
        modifier = Modifier
            .fillMaxSize()
            .then(modifier),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(32.dp))
        Text(
            modifier = modifier
                .wrapContentSize()
                .padding(horizontal = 48.dp),
            text = stringResource(id = R.string.Snabble_Phone_EnterOtp, phoneNumber),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(32.dp))
        Text(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            text = stringResource(id = R.string.Snabble_Phone_CodeLabel)
        )
        Spacer(modifier = Modifier.height(4.dp))
        TextField(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(
                    border = BorderStroke(
                        width = if (focusedDivider.value) 2.dp else 1.dp,
                        color = borderColor
                    ),
                    shape = RoundedCornerShape(4.dp)
                )
                .focusRequester(focusRequester)
                .onFocusEvent {
                    focusedDivider.value = it.isFocused
                }
                .onGloballyPositioned {
                    autofillNode.boundingBox = it.boundsInWindow()
                }
                .onFocusChanged { focusState ->
                    autofill?.run {
                        if (focusState.isFocused) {
                            requestAutofillForNode(autofillNode)
                        } else {
                            cancelAutofillForNode(autofillNode)
                        }
                    }
                },
            textStyle = TextStyle(
                textAlign = TextAlign.Center
            ),
            value = otp.value,
            singleLine = true,
            maxLines = 1,
            onValueChange = { otp.value = it },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                disabledContainerColor = Color.White,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent
            ),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = {
                    onAction(otp.value)
                    focusManager.clearFocus()
                }
            )
        )
        if (isError && !focusedDivider.value) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                text = errorMessage,
                color = Color.Red
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            onClick = {
                onAction(otp.value)
                focusManager.clearFocus()
            },
            enabled = otp.value.length >= OTP_LENGTH
        ) {
            Text(text = stringResource(id = R.string.Snabble_Phone_Continue))
            if (showLoadingIndicator) {
                Spacer(modifier = Modifier.width(8.dp))
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        AnimatedLoadingButton(
            text = stringResource(
                id = R.string.Snabble_Phone_NewRequest
            ),
            refreshRate = refreshRate,
            onclick = { onNewRequest() }
        )
        Spacer(modifier = Modifier.weight(1f))
        TextButton(
            onClick = { onCancel() }
        ) {
            Text(text = stringResource(id = R.string.Snabble_Phone_Back))
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

internal const val OTP_LENGTH = 6

@Preview(
    showSystemUi = true,
    showBackground = true
)
@Composable
fun OtpScreenPreview() {
    OtpScreen(
        phoneNumber = "+3123123123",
        isError = false,
        onAction = {},
        onCancel = {},
        onNewRequest = {}
    )
}
