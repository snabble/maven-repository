package io.snabble.phoneauth.ui.sharedViewModel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class PhoneAuthViewModel : ViewModel() {

    private val _phoneAuthState = MutableStateFlow<PhoneAuthState>(Idle)
    val state = _phoneAuthState.asStateFlow()

    private val _phoneAuthEvent = MutableStateFlow<PhoneAuthEvent>(Init)
    val event = _phoneAuthEvent.asStateFlow()

    fun sendEvent(event: PhoneAuthEvent) {
        _phoneAuthState.tryEmit(Loading)
        _phoneAuthEvent.value = event
    }

    fun onSuccess() {
        _phoneAuthState.tryEmit(Success)
    }

    fun onError(message: String) {
        _phoneAuthState.tryEmit(Error(message))
        _phoneAuthEvent.tryEmit(Init)
    }

    fun reset() {
        _phoneAuthState.tryEmit(Idle)
        _phoneAuthEvent.tryEmit(Init)
    }
}

sealed interface PhoneAuthEvent

object Init : PhoneAuthEvent
object Abort : PhoneAuthEvent

data class RequestOtp(
    val phoneNumber: String,
) : PhoneAuthEvent

data class RefreshOtp(
    val phoneNumber: String,
) : PhoneAuthEvent

data class SendOtp(
    val phoneNumber: String,
    val otp: String,
) : PhoneAuthEvent

sealed interface PhoneAuthState

object Idle : PhoneAuthState

object Loading : PhoneAuthState

object Success : PhoneAuthState

data class Error(
    val message: String,
) : PhoneAuthState
