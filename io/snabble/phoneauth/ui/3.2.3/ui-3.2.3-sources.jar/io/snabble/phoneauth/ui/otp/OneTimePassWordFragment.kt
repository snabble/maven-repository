package io.snabble.phoneauth.ui.otp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.ComposeView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import io.snabble.phoneauth.ui.sharedViewModel.Abort
import io.snabble.phoneauth.ui.sharedViewModel.Error
import io.snabble.phoneauth.ui.sharedViewModel.Idle
import io.snabble.phoneauth.ui.sharedViewModel.Loading
import io.snabble.phoneauth.ui.sharedViewModel.PhoneAuthViewModel
import io.snabble.phoneauth.ui.sharedViewModel.RefreshOtp
import io.snabble.phoneauth.ui.sharedViewModel.SendOtp
import io.snabble.phoneauth.ui.sharedViewModel.Success
import io.snabble.phoneauth.ui.theme.SnabblePhoneAuthTheme

class OneTimePassWordFragment : Fragment() {

    private val viewModel: PhoneAuthViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        val phoneNumber = arguments?.getString("phoneNumber") ?: ""
        return ComposeView(requireContext()).apply {
            setContent {
                val state = viewModel.state.collectAsState()
                val error = remember {
                    mutableStateOf(false)
                }
                val errorMessage = remember {
                    mutableStateOf("")
                }

                val loading = remember {
                    mutableStateOf(false)
                }
                when (val currentState = state.value) {
                    Idle -> {
                        error.value = false
                        loading.value = false
                    }

                    is Error -> {
                        error.value = true
                        errorMessage.value = currentState.message
                        loading.value = false
                    }

                    Loading -> {
                        error.value = false
                        loading.value = true
                    }

                    Success -> {
                        error.value = false
                        loading.value = false
                    }
                }
                SnabblePhoneAuthTheme {
                    OtpScreen(
                        isError = error.value,
                        showLoadingIndicator = loading.value,
                        errorMessage = errorMessage.value,
                        phoneNumber = phoneNumber,
                        onAction = { viewModel.sendEvent(SendOtp(phoneNumber, it)) },
                        onNewRequest = { viewModel.sendEvent(RefreshOtp(phoneNumber)) },
                        onCancel = { viewModel.sendEvent(Abort) }
                    )
                }
            }
        }
    }
}
